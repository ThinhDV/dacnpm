Liferay.Service.register("Liferay.Service.VS", "com.vsi.lienketwebsite.service", "LienKetWebsite-portlet");

Liferay.Service.registerClass(
	Liferay.Service.VS, "LinkGroup",
	{
		addLinkGroup: true,
		getLinkGroups: true,
		getLinkGroup: true,
		updateLinkGroup: true,
		deleteLinkGroup: true
	}
);

Liferay.Service.registerClass(
	Liferay.Service.VS, "Links",
	{
		addLink: true,
		getLinks: true,
		getLink: true,
		updateLinks: true,
		deleteLinks: true,
		getLinkBylinkgroupId: true
	}
);