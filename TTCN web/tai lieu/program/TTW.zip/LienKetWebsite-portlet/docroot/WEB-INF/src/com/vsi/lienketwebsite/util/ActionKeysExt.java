package com.vsi.lienketwebsite.util;

public class ActionKeysExt {
	
	public static final String ADD_LINK = "ADD_LINK";	
	
	public static final String ADD_LINK_GROUP = "ADD_LINK_GROUP";
	
	public static final String UPDATE = "UPDATE";
	
	public static final String DELETE = "DELETE";
	
	public static final String DELETE_ALL = "DELETE_ALL";
	
	public static final String VIEW = "VIEW";
	
	public static final String CONFIGURATION  = "CONFIGURATION";
	
	public static final String PERMISSIONS  = "PERMISSIONS";
}
