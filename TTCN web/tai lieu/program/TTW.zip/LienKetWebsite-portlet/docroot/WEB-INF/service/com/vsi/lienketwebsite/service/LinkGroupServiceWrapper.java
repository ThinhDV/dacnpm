/**
 * Copyright (c) 2000-2012 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.vsi.lienketwebsite.service;

import com.liferay.portal.service.ServiceWrapper;

/**
 * <p>
 * This class is a wrapper for {@link LinkGroupService}.
 * </p>
 *
 * @author    Administrator
 * @see       LinkGroupService
 * @generated
 */
public class LinkGroupServiceWrapper implements LinkGroupService,
	ServiceWrapper<LinkGroupService> {
	public LinkGroupServiceWrapper(LinkGroupService linkGroupService) {
		_linkGroupService = linkGroupService;
	}

	public com.vsi.lienketwebsite.model.LinkGroup addLinkGroup(
		com.vsi.lienketwebsite.model.LinkGroup newLinkGroup)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _linkGroupService.addLinkGroup(newLinkGroup);
	}

	public java.util.List<com.vsi.lienketwebsite.model.LinkGroup> getLinkGroups(
		long groupId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _linkGroupService.getLinkGroups(groupId);
	}

	public com.vsi.lienketwebsite.model.LinkGroup getLinkGroup(long linkGroupId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _linkGroupService.getLinkGroup(linkGroupId);
	}

	public com.vsi.lienketwebsite.model.LinkGroup updateLinkGroup(
		long linkgroupId, long groupId, long companyId, java.lang.String name,
		java.lang.String description)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException,
			java.rmi.RemoteException {
		return _linkGroupService.updateLinkGroup(linkgroupId, groupId,
			companyId, name, description);
	}

	public com.vsi.lienketwebsite.model.LinkGroup updateLinkGroup(
		com.vsi.lienketwebsite.model.LinkGroup linkGroup)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException,
			java.rmi.RemoteException {
		return _linkGroupService.updateLinkGroup(linkGroup);
	}

	public void deleteLinkGroup(long linkgroupId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException,
			java.rmi.RemoteException {
		_linkGroupService.deleteLinkGroup(linkgroupId);
	}

	/**
	 * @deprecated Renamed to {@link #getWrappedService}
	 */
	public LinkGroupService getWrappedLinkGroupService() {
		return _linkGroupService;
	}

	/**
	 * @deprecated Renamed to {@link #setWrappedService}
	 */
	public void setWrappedLinkGroupService(LinkGroupService linkGroupService) {
		_linkGroupService = linkGroupService;
	}

	public LinkGroupService getWrappedService() {
		return _linkGroupService;
	}

	public void setWrappedService(LinkGroupService linkGroupService) {
		_linkGroupService = linkGroupService;
	}

	private LinkGroupService _linkGroupService;
}