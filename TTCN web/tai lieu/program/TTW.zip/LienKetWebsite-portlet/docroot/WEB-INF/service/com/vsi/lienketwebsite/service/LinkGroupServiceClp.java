/**
 * Copyright (c) 2000-2012 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.vsi.lienketwebsite.service;

import com.liferay.portal.kernel.util.ClassLoaderProxy;
import com.liferay.portal.kernel.util.MethodHandler;
import com.liferay.portal.kernel.util.MethodKey;

/**
 * @author Administrator
 */
public class LinkGroupServiceClp implements LinkGroupService {
	public LinkGroupServiceClp(ClassLoaderProxy classLoaderProxy) {
		_classLoaderProxy = classLoaderProxy;

		_addLinkGroupMethodKey0 = new MethodKey(_classLoaderProxy.getClassName(),
				"addLinkGroup", com.vsi.lienketwebsite.model.LinkGroup.class);

		_getLinkGroupsMethodKey1 = new MethodKey(_classLoaderProxy.getClassName(),
				"getLinkGroups", long.class);

		_getLinkGroupMethodKey2 = new MethodKey(_classLoaderProxy.getClassName(),
				"getLinkGroup", long.class);

		_updateLinkGroupMethodKey3 = new MethodKey(_classLoaderProxy.getClassName(),
				"updateLinkGroup", long.class, long.class, long.class,
				java.lang.String.class, java.lang.String.class);

		_updateLinkGroupMethodKey4 = new MethodKey(_classLoaderProxy.getClassName(),
				"updateLinkGroup", com.vsi.lienketwebsite.model.LinkGroup.class);

		_deleteLinkGroupMethodKey5 = new MethodKey(_classLoaderProxy.getClassName(),
				"deleteLinkGroup", long.class);
	}

	public com.vsi.lienketwebsite.model.LinkGroup addLinkGroup(
		com.vsi.lienketwebsite.model.LinkGroup newLinkGroup)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		Object returnObj = null;

		MethodHandler methodHandler = new MethodHandler(_addLinkGroupMethodKey0,
				ClpSerializer.translateInput(newLinkGroup));

		try {
			returnObj = _classLoaderProxy.invoke(methodHandler);
		}
		catch (Throwable t) {
			if (t instanceof com.liferay.portal.kernel.exception.PortalException) {
				throw (com.liferay.portal.kernel.exception.PortalException)t;
			}

			if (t instanceof com.liferay.portal.kernel.exception.SystemException) {
				throw (com.liferay.portal.kernel.exception.SystemException)t;
			}

			if (t instanceof RuntimeException) {
				throw (RuntimeException)t;
			}
			else {
				throw new RuntimeException(t.getClass().getName() +
					" is not a valid exception");
			}
		}

		return (com.vsi.lienketwebsite.model.LinkGroup)ClpSerializer.translateOutput(returnObj);
	}

	public java.util.List<com.vsi.lienketwebsite.model.LinkGroup> getLinkGroups(
		long groupId)
		throws com.liferay.portal.kernel.exception.SystemException {
		Object returnObj = null;

		MethodHandler methodHandler = new MethodHandler(_getLinkGroupsMethodKey1,
				groupId);

		try {
			returnObj = _classLoaderProxy.invoke(methodHandler);
		}
		catch (Throwable t) {
			if (t instanceof com.liferay.portal.kernel.exception.SystemException) {
				throw (com.liferay.portal.kernel.exception.SystemException)t;
			}

			if (t instanceof RuntimeException) {
				throw (RuntimeException)t;
			}
			else {
				throw new RuntimeException(t.getClass().getName() +
					" is not a valid exception");
			}
		}

		return (java.util.List<com.vsi.lienketwebsite.model.LinkGroup>)ClpSerializer.translateOutput(returnObj);
	}

	public com.vsi.lienketwebsite.model.LinkGroup getLinkGroup(long linkGroupId)
		throws com.liferay.portal.kernel.exception.SystemException {
		Object returnObj = null;

		MethodHandler methodHandler = new MethodHandler(_getLinkGroupMethodKey2,
				linkGroupId);

		try {
			returnObj = _classLoaderProxy.invoke(methodHandler);
		}
		catch (Throwable t) {
			if (t instanceof com.liferay.portal.kernel.exception.SystemException) {
				throw (com.liferay.portal.kernel.exception.SystemException)t;
			}

			if (t instanceof RuntimeException) {
				throw (RuntimeException)t;
			}
			else {
				throw new RuntimeException(t.getClass().getName() +
					" is not a valid exception");
			}
		}

		return (com.vsi.lienketwebsite.model.LinkGroup)ClpSerializer.translateOutput(returnObj);
	}

	public com.vsi.lienketwebsite.model.LinkGroup updateLinkGroup(
		long linkgroupId, long groupId, long companyId, java.lang.String name,
		java.lang.String description)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException,
			java.rmi.RemoteException {
		Object returnObj = null;

		MethodHandler methodHandler = new MethodHandler(_updateLinkGroupMethodKey3,
				linkgroupId, groupId, companyId,
				ClpSerializer.translateInput(name),
				ClpSerializer.translateInput(description));

		try {
			returnObj = _classLoaderProxy.invoke(methodHandler);
		}
		catch (Throwable t) {
			if (t instanceof com.liferay.portal.kernel.exception.PortalException) {
				throw (com.liferay.portal.kernel.exception.PortalException)t;
			}

			if (t instanceof com.liferay.portal.kernel.exception.SystemException) {
				throw (com.liferay.portal.kernel.exception.SystemException)t;
			}

			if (t instanceof java.rmi.RemoteException) {
				throw (java.rmi.RemoteException)t;
			}

			if (t instanceof RuntimeException) {
				throw (RuntimeException)t;
			}
			else {
				throw new RuntimeException(t.getClass().getName() +
					" is not a valid exception");
			}
		}

		return (com.vsi.lienketwebsite.model.LinkGroup)ClpSerializer.translateOutput(returnObj);
	}

	public com.vsi.lienketwebsite.model.LinkGroup updateLinkGroup(
		com.vsi.lienketwebsite.model.LinkGroup linkGroup)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException,
			java.rmi.RemoteException {
		Object returnObj = null;

		MethodHandler methodHandler = new MethodHandler(_updateLinkGroupMethodKey4,
				ClpSerializer.translateInput(linkGroup));

		try {
			returnObj = _classLoaderProxy.invoke(methodHandler);
		}
		catch (Throwable t) {
			if (t instanceof com.liferay.portal.kernel.exception.PortalException) {
				throw (com.liferay.portal.kernel.exception.PortalException)t;
			}

			if (t instanceof com.liferay.portal.kernel.exception.SystemException) {
				throw (com.liferay.portal.kernel.exception.SystemException)t;
			}

			if (t instanceof java.rmi.RemoteException) {
				throw (java.rmi.RemoteException)t;
			}

			if (t instanceof RuntimeException) {
				throw (RuntimeException)t;
			}
			else {
				throw new RuntimeException(t.getClass().getName() +
					" is not a valid exception");
			}
		}

		return (com.vsi.lienketwebsite.model.LinkGroup)ClpSerializer.translateOutput(returnObj);
	}

	public void deleteLinkGroup(long linkgroupId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException,
			java.rmi.RemoteException {
		MethodHandler methodHandler = new MethodHandler(_deleteLinkGroupMethodKey5,
				linkgroupId);

		try {
			_classLoaderProxy.invoke(methodHandler);
		}
		catch (Throwable t) {
			if (t instanceof com.liferay.portal.kernel.exception.PortalException) {
				throw (com.liferay.portal.kernel.exception.PortalException)t;
			}

			if (t instanceof com.liferay.portal.kernel.exception.SystemException) {
				throw (com.liferay.portal.kernel.exception.SystemException)t;
			}

			if (t instanceof java.rmi.RemoteException) {
				throw (java.rmi.RemoteException)t;
			}

			if (t instanceof RuntimeException) {
				throw (RuntimeException)t;
			}
			else {
				throw new RuntimeException(t.getClass().getName() +
					" is not a valid exception");
			}
		}
	}

	public ClassLoaderProxy getClassLoaderProxy() {
		return _classLoaderProxy;
	}

	private ClassLoaderProxy _classLoaderProxy;
	private MethodKey _addLinkGroupMethodKey0;
	private MethodKey _getLinkGroupsMethodKey1;
	private MethodKey _getLinkGroupMethodKey2;
	private MethodKey _updateLinkGroupMethodKey3;
	private MethodKey _updateLinkGroupMethodKey4;
	private MethodKey _deleteLinkGroupMethodKey5;
}