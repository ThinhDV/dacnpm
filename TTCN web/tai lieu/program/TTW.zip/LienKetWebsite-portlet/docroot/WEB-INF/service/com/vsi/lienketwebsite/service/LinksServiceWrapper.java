/**
 * Copyright (c) 2000-2012 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.vsi.lienketwebsite.service;

import com.liferay.portal.service.ServiceWrapper;

/**
 * <p>
 * This class is a wrapper for {@link LinksService}.
 * </p>
 *
 * @author    Administrator
 * @see       LinksService
 * @generated
 */
public class LinksServiceWrapper implements LinksService,
	ServiceWrapper<LinksService> {
	public LinksServiceWrapper(LinksService linksService) {
		_linksService = linksService;
	}

	public com.vsi.lienketwebsite.model.Links addLink(
		com.vsi.lienketwebsite.model.Links newLink)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _linksService.addLink(newLink);
	}

	public java.util.List<com.vsi.lienketwebsite.model.Links> getLinks(
		long groupId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _linksService.getLinks(groupId);
	}

	public com.vsi.lienketwebsite.model.Links getLink(long linkId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _linksService.getLink(linkId);
	}

	public com.vsi.lienketwebsite.model.Links updateLinks(long linkId,
		long groupId, long companyId, long linkgroupId, java.lang.String name,
		java.lang.String description, java.lang.String url, int position)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException,
			java.rmi.RemoteException {
		return _linksService.updateLinks(linkId, groupId, companyId,
			linkgroupId, name, description, url, position);
	}

	public com.vsi.lienketwebsite.model.Links updateLinks(
		com.vsi.lienketwebsite.model.Links links)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException,
			java.rmi.RemoteException {
		return _linksService.updateLinks(links);
	}

	public void deleteLinks(long linkId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException,
			java.rmi.RemoteException {
		_linksService.deleteLinks(linkId);
	}

	public java.util.List<com.vsi.lienketwebsite.model.Links> getLinkBylinkgroupId(
		long linkgroupId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _linksService.getLinkBylinkgroupId(linkgroupId);
	}

	/**
	 * @deprecated Renamed to {@link #getWrappedService}
	 */
	public LinksService getWrappedLinksService() {
		return _linksService;
	}

	/**
	 * @deprecated Renamed to {@link #setWrappedService}
	 */
	public void setWrappedLinksService(LinksService linksService) {
		_linksService = linksService;
	}

	public LinksService getWrappedService() {
		return _linksService;
	}

	public void setWrappedService(LinksService linksService) {
		_linksService = linksService;
	}

	private LinksService _linksService;
}