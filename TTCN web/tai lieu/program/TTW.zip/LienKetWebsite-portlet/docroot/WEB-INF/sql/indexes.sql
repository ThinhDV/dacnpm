create index IX_D4F9B041 on VS_LinkGroup (groupId);

create index IX_3662EFAD on VS_Links (groupId);
create index IX_29D9A063 on VS_Links (groupId, linkgroupId);
create index IX_E1B13073 on VS_Links (linkgroupId);