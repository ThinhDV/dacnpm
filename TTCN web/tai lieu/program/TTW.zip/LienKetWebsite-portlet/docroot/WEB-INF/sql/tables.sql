create table VS_LinkGroup (
	linkgroupId LONG not null primary key,
	groupId LONG,
	companyId LONG,
	createdDate DATE null,
	modifiedDate DATE null,
	name VARCHAR(75) null,
	description VARCHAR(75) null
);

create table VS_Links (
	linkId LONG not null primary key,
	groupId LONG,
	companyId LONG,
	createdDate DATE null,
	modifiedDate DATE null,
	linkgroupId LONG,
	name VARCHAR(75) null,
	description VARCHAR(75) null,
	url VARCHAR(75) null,
	position INTEGER
);