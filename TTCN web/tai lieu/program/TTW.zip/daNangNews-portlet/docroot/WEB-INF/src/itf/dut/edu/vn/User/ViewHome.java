package itf.dut.edu.vn.User;

import com.liferay.util.bridges.mvc.MVCPortlet;

/**
 * Portlet implementation class ViewHome
 */
public class ViewHome extends MVCPortlet {
 

}
