package itf.dut.edu.vn.Admin;

import itf.dut.edu.vn.model.Category;
import itf.dut.edu.vn.model.News;
import itf.dut.edu.vn.model.impl.CategoryImpl;
import itf.dut.edu.vn.model.impl.NewsImpl;
import itf.dut.edu.vn.service.CategoryLocalServiceUtil;
import itf.dut.edu.vn.service.NewsLocalServiceUtil;

import java.util.Date;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.util.bridges.mvc.MVCPortlet;

/**
 * Portlet implementation class NewsAdmin
 */
public class NewsAdmin extends MVCPortlet {

	protected String editNewsJSP = "/html/newsadmin/edit_news.jsp";
	protected String editCategoryJSP = "/html/newsadmin/edit_category.jsp";
	protected String viewCategoryJSP = "/html/newsadmin/view_category.jsp";
	

	public void addNews(ActionRequest request, ActionResponse response)
			throws SystemException, PortalException {
		ThemeDisplay themeDisplay = (ThemeDisplay) request
				.getAttribute(WebKeys.THEME_DISPLAY);
		long newsId = 0l;
		try {
			newsId = CounterLocalServiceUtil.increment(this.getClass().getName());
			
		} catch (SystemException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String title = ParamUtil.getString(request, "title");
		String urlImage = ParamUtil.getString(request, "urlImage");
		String summarize = ParamUtil.getString(request, "summarize");
		String writer = ParamUtil.getString(request, "writer");
		// Date createDate = new Date();
		// Date modifiedDate = new Date();
		long categoryId = ParamUtil.getLong(request, "categoryId");
		String contentNews = ParamUtil.getString(request, "contentNews");

		long groupId = themeDisplay.getScopeGroupId();
		long companyId = themeDisplay.getCompanyId();
		boolean mainNews = ParamUtil.getBoolean(request, "mainNews");
		News news = new NewsImpl();
		news.setNewsId(newsId);
		news.setTitle(title);
		news.setUrlImage(urlImage);
		news.setSummarize(summarize);
		news.setCreateDate(new Date());
		news.setCategoryId(categoryId);
		news.setContentNews(contentNews);
		news.setCountView(0);
		news.setGroupId(groupId);
		news.setCompanyId(companyId);
		news.setMainNews(mainNews);
		news.setWriter(writer);
		NewsLocalServiceUtil.addNews(news);
		System.out.println(contentNews + "fdf");
		

	}

	public void addCategory(ActionRequest request, ActionResponse response)
			throws SystemException, PortalException {
		ThemeDisplay themeDisplay = (ThemeDisplay) request
				.getAttribute(WebKeys.THEME_DISPLAY);
		long categoryId = 0l;
		try {
			categoryId = CounterLocalServiceUtil.increment(this.getClass().getName());
			
		} catch (SystemException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String nameCategory = ParamUtil.getString(request, "nameCategory");
		long groupId = themeDisplay.getScopeGroupId();
		long companyId = themeDisplay.getCompanyId();
		
		Category category = new CategoryImpl();
		category.setCategoryId(categoryId);
		category.setNameCategory(nameCategory);
		category.setCompanyId(companyId);
		category.setGroupId(groupId);

		CategoryLocalServiceUtil.addCategory(category);
	}

	public void deleteNews(ActionRequest request, ActionResponse response)
			throws SystemException, PortalException {
		// int goodSentencesKey = ParamUtil.getInteger(request,
		// "resourcePrimKey");
		long resourcePrimKey = ParamUtil.getLong(request, "resourcePrimKey");
		// if (Validator.isNotNull(linkGroupKey)) {

		NewsLocalServiceUtil.deleteNews(resourcePrimKey);

		SessionMessages.add(request, "News deleted");
	}

	public void deleteCategory(ActionRequest request, ActionResponse response)
			throws SystemException, PortalException {
		long resourcePrimKey = ParamUtil.getLong(request, "resourcePrimKey");
		CategoryLocalServiceUtil.deleteCategory(resourcePrimKey);
	}

	public void editNews(ActionRequest request, ActionResponse response)
			throws SystemException, PortalException {
		int resourcePrimKey = ParamUtil.getInteger(request, "resourcePrimKey");

		// if (Validator.isNotNull(linkGroupKey)) {
		// LinkGroup linkGroup = LinkGroupServiceUtil.getLinkGroup(sentenceId);
		News news = NewsLocalServiceUtil.getNews(resourcePrimKey);
		request.setAttribute("news", news);
		response.setRenderParameter("jspPage", editNewsJSP);

		// }

	}

	public void editCategory(ActionRequest request, ActionResponse response)
			throws SystemException, PortalException {
		int resourcePrimKey = ParamUtil.getInteger(request, "resourcePrimKey");
		Category category = CategoryLocalServiceUtil.getCategory(resourcePrimKey);
		request.setAttribute("category", category);
		response.setRenderParameter("jspPage", editCategoryJSP);
	}

	public void updateNews(ActionRequest request, ActionResponse response)
			throws Exception {

		ThemeDisplay themeDisplay = (ThemeDisplay) request
				.getAttribute(WebKeys.THEME_DISPLAY);

		long newsId = ParamUtil.getLong(request, "resourcePrimKey");
		String title = ParamUtil.getString(request, "title");
		String urlImage = ParamUtil.getString(request, "urlImage");
		String summarize = ParamUtil.getString(request, "summarize");
		long categoryId = ParamUtil.getLong(request, "categoryId");
		String contentNews = ParamUtil.getString(request, "contentNews");

		long groupId = themeDisplay.getScopeGroupId();
		long companyId = themeDisplay.getCompanyId();
		boolean mainNews = ParamUtil.getBoolean(request, "mainNews");
//		News news = new NewsImpl();
		News news = NewsLocalServiceUtil.getNews(newsId);
		news.setNewsId(newsId);
		news.setTitle(title);
		news.setUrlImage(urlImage);
		news.setSummarize(summarize);
		news.setModifiedDate(new Date());
		news.setCategoryId(categoryId);
		news.setContentNews(contentNews);

		// news.setCountView(NewsLocalServiceUtil.getNews(newsId).getCountView()+1);
		news.setGroupId(groupId);
		news.setCompanyId(companyId);
		news.setMainNews(mainNews);
		//NewsLocalServiceUtil.addNews(news);
		NewsLocalServiceUtil.updateNews(news);

		// GoodSentencesUtil.findBygroupId(groupId)

	}
	
	public void updateCategory(ActionRequest request, ActionResponse response)
			throws Exception {
		ThemeDisplay themeDisplay = (ThemeDisplay) request
				.getAttribute(WebKeys.THEME_DISPLAY);
		int categoryId = ParamUtil.getInteger(request, "resourcePrimKey");
		String nameCategory = ParamUtil.getString(request, "nameCategory");
		long groupId = themeDisplay.getScopeGroupId();
		long companyId = themeDisplay.getCompanyId();
		Category category = new CategoryImpl();
		category.setCategoryId(categoryId);
		category.setNameCategory(nameCategory);
		category.setCompanyId(companyId);
		category.setGroupId(groupId);

		CategoryLocalServiceUtil.updateCategory(category);
		response.setRenderParameter("jspPage", viewCategoryJSP);
	}

}
