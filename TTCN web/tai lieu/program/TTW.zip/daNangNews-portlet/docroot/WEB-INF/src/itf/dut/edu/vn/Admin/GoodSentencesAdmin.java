package itf.dut.edu.vn.Admin;

import itf.dut.edu.vn.model.GoodSentences;
import itf.dut.edu.vn.model.impl.GoodSentencesImpl;
import itf.dut.edu.vn.service.GoodSentencesLocalService;
import itf.dut.edu.vn.service.GoodSentencesLocalServiceUtil;
import itf.dut.edu.vn.service.GoodSentencesService;
import itf.dut.edu.vn.service.GoodSentencesServiceUtil;
import itf.dut.edu.vn.service.persistence.GoodSentencesPersistence;
import itf.dut.edu.vn.service.persistence.GoodSentencesPersistenceImpl;
import itf.dut.edu.vn.service.persistence.GoodSentencesUtil;
import itf.dut.edu.vn.util.ActionUtil;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;


import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.util.bridges.mvc.MVCPortlet;

/**
 * Portlet implementation class GoodSentencesAdmin
 */
public class GoodSentencesAdmin extends MVCPortlet {
	
	protected String editGoodSentencesJSP= "/html/goodsentencesadmin/edit_goodSentences.jsp";
	public void addGoodSentences(ActionRequest request, ActionResponse response) throws SystemException, PortalException
	{
//		GoodSentences goodSentences = ActionUtil.prGoodSentencesFromRequest(request);
//		ThemeDisplay themeDisplay =(ThemeDisplay) request.getAttribute(WebKeys.THEME_DISPLAY);
//		//mang de luu tru loi nhap lieu
//		ArrayList<String> errors = new ArrayList<String>();
//		boolean goodSentencesValid = ValidatorUtil.validateGoodSentences(goodSentences, errors);
//		if(goodSentencesValid)
//		{
//			//them vao csdl
//			
//			LinkGroupServiceUtil.addLinkGroup(linkGroup);
//			GoodSentencesLocalServiceUtil.add
//			SessionMessages.add(request, "LinkGroupSaved");
//            response.setRenderParameter("jspPage", viewAddLinkGroup);
//		}
//		 else {
//             for (String error : errors) {
//                 SessionErrors.add(request, error);
//             }
//             SessionErrors.add(request, "LinkGroupErrorSaving");
//		 }		
		
		ThemeDisplay themeDisplay = (ThemeDisplay) request.getAttribute(WebKeys.THEME_DISPLAY);
		String sentence = ParamUtil.getString(request, "sentence");
		int day = ParamUtil.getInteger(request, "day");
		//System.out.println(NewsContent + " " + NewsTitle);		
		GoodSentences goodSentences = new GoodSentencesImpl();
		int id = 0;
		try {
			id = (int) CounterLocalServiceUtil.increment(this.getClass().getName());
			
		} catch (SystemException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		goodSentences.setSentenceId(id);
		goodSentences.setSentence(sentence);
		goodSentences.setCompanyId(themeDisplay.getCompanyId());
		goodSentences.setGroupId(themeDisplay.getScopeGroupId());
		goodSentences.setDay(day);
		
		GoodSentencesLocalServiceUtil.addGoodSentences(goodSentences);
		
		
		
	}
	
	public void deleteGoodSentences(ActionRequest request, ActionResponse response) throws SystemException, PortalException
	{
		
		int goodSentencesKey = ParamUtil.getInteger(request, "resourcePrimKey");

        //if (Validator.isNotNull(linkGroupKey)) {
		GoodSentencesLocalServiceUtil.deleteGoodSentences(goodSentencesKey);
        	//LinkGroupServiceUtil.deleteLinkGroup(linkGroupKey);		          
            SessionMessages.add(request, "GoodSentences deleted");
        //}
        //else {
           // SessionErrors.add(request, "LinkGroupErrorDeleting");
       // }
		
		
	}
	
	public void editGoodSentences(ActionRequest request, ActionResponse response) throws SystemException, PortalException
	{
		int sentenceId = ParamUtil.getInteger(request, "resourcePrimKey");

        //if (Validator.isNotNull(linkGroupKey)) {
		//LinkGroup linkGroup = LinkGroupServiceUtil.getLinkGroup(sentenceId);	
		GoodSentences goodSentences = GoodSentencesLocalServiceUtil.getGoodSentences(sentenceId);
        request.setAttribute("goodSentences", goodSentences);
        response.setRenderParameter("jspPage", editGoodSentencesJSP);
        
        //}
		
		
	}
	
	public void updateGoodSentences(ActionRequest request, ActionResponse response)
	        throws Exception {		
		String sentence = ParamUtil.getString(request, "sentence");
		int day = ParamUtil.getInteger(request, "day");
		int id = ParamUtil.getInteger(request, "resourcePrimKey");			
		GoodSentences goodSentences = new GoodSentencesImpl();		
		goodSentences.setSentenceId(id);
		goodSentences.setSentence(sentence);
		goodSentences.setDay(day);
		
		GoodSentencesLocalServiceUtil.updateGoodSentences(goodSentences);	
		
		//GoodSentencesUtil.findBygroupId(groupId)
		
	}
	

}
