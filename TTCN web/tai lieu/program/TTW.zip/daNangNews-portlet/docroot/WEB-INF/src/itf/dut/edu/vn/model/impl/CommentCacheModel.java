/**
 * Copyright (c) 2000-2012 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package itf.dut.edu.vn.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import itf.dut.edu.vn.model.Comment;

import java.io.Serializable;

import java.util.Date;

/**
 * The cache model class for representing Comment in entity cache.
 *
 * @author thanhlikes09
 * @see Comment
 * @generated
 */
public class CommentCacheModel implements CacheModel<Comment>, Serializable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(21);

		sb.append("{commentId=");
		sb.append(commentId);
		sb.append(", newsId=");
		sb.append(newsId);
		sb.append(", name=");
		sb.append(name);
		sb.append(", email=");
		sb.append(email);
		sb.append(", address=");
		sb.append(address);
		sb.append(", title=");
		sb.append(title);
		sb.append(", contentComment=");
		sb.append(contentComment);
		sb.append(", createDate=");
		sb.append(createDate);
		sb.append(", groupId=");
		sb.append(groupId);
		sb.append(", companyId=");
		sb.append(companyId);
		sb.append("}");

		return sb.toString();
	}

	public Comment toEntityModel() {
		CommentImpl commentImpl = new CommentImpl();

		commentImpl.setCommentId(commentId);
		commentImpl.setNewsId(newsId);

		if (name == null) {
			commentImpl.setName(StringPool.BLANK);
		}
		else {
			commentImpl.setName(name);
		}

		if (email == null) {
			commentImpl.setEmail(StringPool.BLANK);
		}
		else {
			commentImpl.setEmail(email);
		}

		if (address == null) {
			commentImpl.setAddress(StringPool.BLANK);
		}
		else {
			commentImpl.setAddress(address);
		}

		if (title == null) {
			commentImpl.setTitle(StringPool.BLANK);
		}
		else {
			commentImpl.setTitle(title);
		}

		if (contentComment == null) {
			commentImpl.setContentComment(StringPool.BLANK);
		}
		else {
			commentImpl.setContentComment(contentComment);
		}

		if (createDate == Long.MIN_VALUE) {
			commentImpl.setCreateDate(null);
		}
		else {
			commentImpl.setCreateDate(new Date(createDate));
		}

		commentImpl.setGroupId(groupId);
		commentImpl.setCompanyId(companyId);

		commentImpl.resetOriginalValues();

		return commentImpl;
	}

	public long commentId;
	public long newsId;
	public String name;
	public String email;
	public String address;
	public String title;
	public String contentComment;
	public long createDate;
	public long groupId;
	public long companyId;
}