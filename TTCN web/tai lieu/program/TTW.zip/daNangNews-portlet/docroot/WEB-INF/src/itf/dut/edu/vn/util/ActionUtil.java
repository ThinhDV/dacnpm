package itf.dut.edu.vn.util;


public class ActionUtil {
//	public static GoodSentences prGoodSentencesFromRequest(ActionRequest request)
//	{
//		ThemeDisplay themeDisplay = (ThemeDisplay) request.getAttribute(WebKeys.THEME_DISPLAY);
//		GoodSentences goodSentences = new GoodSentencesImpl();
//		goodSentences.setCompanyId(themeDisplay.getCompanyId());
//		goodSentences.setGroupId(themeDisplay.getScopeGroupId());
//		goodSentences.setSentence(ParamUtil.getString(request, "sentence"));				
//		return goodSentences;
//	}	
	
	
}
