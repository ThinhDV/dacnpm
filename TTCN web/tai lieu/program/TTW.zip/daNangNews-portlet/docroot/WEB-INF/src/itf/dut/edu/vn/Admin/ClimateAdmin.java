package itf.dut.edu.vn.Admin;

import com.liferay.util.bridges.mvc.MVCPortlet;

/**
 * Portlet implementation class ClimateAdmin
 */
public class ClimateAdmin extends MVCPortlet {
 

}
