/**
 * Copyright (c) 2000-2012 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package itf.dut.edu.vn.service.persistence;

import com.liferay.portal.NoSuchModelException;
import com.liferay.portal.kernel.bean.BeanReference;
import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.BatchSessionUtil;
import com.liferay.portal.service.persistence.ResourcePersistence;
import com.liferay.portal.service.persistence.UserPersistence;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import itf.dut.edu.vn.NoSuchNewsException;
import itf.dut.edu.vn.model.News;
import itf.dut.edu.vn.model.impl.NewsImpl;
import itf.dut.edu.vn.model.impl.NewsModelImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The persistence implementation for the news service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author thanhlikes09
 * @see NewsPersistence
 * @see NewsUtil
 * @generated
 */
public class NewsPersistenceImpl extends BasePersistenceImpl<News>
	implements NewsPersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link NewsUtil} to access the news persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = NewsImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_FETCH_BY_TITLE = new FinderPath(NewsModelImpl.ENTITY_CACHE_ENABLED,
			NewsModelImpl.FINDER_CACHE_ENABLED, NewsImpl.class,
			FINDER_CLASS_NAME_ENTITY, "fetchBytitle",
			new String[] { String.class.getName() },
			NewsModelImpl.TITLE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_TITLE = new FinderPath(NewsModelImpl.ENTITY_CACHE_ENABLED,
			NewsModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBytitle",
			new String[] { String.class.getName() });
	public static final FinderPath FINDER_PATH_FETCH_BY_CONTENTNEWS = new FinderPath(NewsModelImpl.ENTITY_CACHE_ENABLED,
			NewsModelImpl.FINDER_CACHE_ENABLED, NewsImpl.class,
			FINDER_CLASS_NAME_ENTITY, "fetchBycontentNews",
			new String[] { String.class.getName() },
			NewsModelImpl.CONTENTNEWS_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_CONTENTNEWS = new FinderPath(NewsModelImpl.ENTITY_CACHE_ENABLED,
			NewsModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBycontentNews",
			new String[] { String.class.getName() });
	public static final FinderPath FINDER_PATH_FETCH_BY_CATEGORYID = new FinderPath(NewsModelImpl.ENTITY_CACHE_ENABLED,
			NewsModelImpl.FINDER_CACHE_ENABLED, NewsImpl.class,
			FINDER_CLASS_NAME_ENTITY, "fetchBycategoryId",
			new String[] { Long.class.getName() },
			NewsModelImpl.CATEGORYID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_CATEGORYID = new FinderPath(NewsModelImpl.ENTITY_CACHE_ENABLED,
			NewsModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBycategoryId",
			new String[] { Long.class.getName() });
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(NewsModelImpl.ENTITY_CACHE_ENABLED,
			NewsModelImpl.FINDER_CACHE_ENABLED, NewsImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(NewsModelImpl.ENTITY_CACHE_ENABLED,
			NewsModelImpl.FINDER_CACHE_ENABLED, NewsImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(NewsModelImpl.ENTITY_CACHE_ENABLED,
			NewsModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);

	/**
	 * Caches the news in the entity cache if it is enabled.
	 *
	 * @param news the news
	 */
	public void cacheResult(News news) {
		EntityCacheUtil.putResult(NewsModelImpl.ENTITY_CACHE_ENABLED,
			NewsImpl.class, news.getPrimaryKey(), news);

		FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_TITLE,
			new Object[] { news.getTitle() }, news);

		FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_CONTENTNEWS,
			new Object[] { news.getContentNews() }, news);

		FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_CATEGORYID,
			new Object[] { Long.valueOf(news.getCategoryId()) }, news);

		news.resetOriginalValues();
	}

	/**
	 * Caches the newses in the entity cache if it is enabled.
	 *
	 * @param newses the newses
	 */
	public void cacheResult(List<News> newses) {
		for (News news : newses) {
			if (EntityCacheUtil.getResult(NewsModelImpl.ENTITY_CACHE_ENABLED,
						NewsImpl.class, news.getPrimaryKey()) == null) {
				cacheResult(news);
			}
			else {
				news.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all newses.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(NewsImpl.class.getName());
		}

		EntityCacheUtil.clearCache(NewsImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the news.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(News news) {
		EntityCacheUtil.removeResult(NewsModelImpl.ENTITY_CACHE_ENABLED,
			NewsImpl.class, news.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		clearUniqueFindersCache(news);
	}

	@Override
	public void clearCache(List<News> newses) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (News news : newses) {
			EntityCacheUtil.removeResult(NewsModelImpl.ENTITY_CACHE_ENABLED,
				NewsImpl.class, news.getPrimaryKey());

			clearUniqueFindersCache(news);
		}
	}

	protected void clearUniqueFindersCache(News news) {
		FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_TITLE,
			new Object[] { news.getTitle() });

		FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_CONTENTNEWS,
			new Object[] { news.getContentNews() });

		FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_CATEGORYID,
			new Object[] { Long.valueOf(news.getCategoryId()) });
	}

	/**
	 * Creates a new news with the primary key. Does not add the news to the database.
	 *
	 * @param newsId the primary key for the new news
	 * @return the new news
	 */
	public News create(long newsId) {
		News news = new NewsImpl();

		news.setNew(true);
		news.setPrimaryKey(newsId);

		return news;
	}

	/**
	 * Removes the news with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param newsId the primary key of the news
	 * @return the news that was removed
	 * @throws itf.dut.edu.vn.NoSuchNewsException if a news with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	public News remove(long newsId) throws NoSuchNewsException, SystemException {
		return remove(Long.valueOf(newsId));
	}

	/**
	 * Removes the news with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the news
	 * @return the news that was removed
	 * @throws itf.dut.edu.vn.NoSuchNewsException if a news with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public News remove(Serializable primaryKey)
		throws NoSuchNewsException, SystemException {
		Session session = null;

		try {
			session = openSession();

			News news = (News)session.get(NewsImpl.class, primaryKey);

			if (news == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchNewsException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(news);
		}
		catch (NoSuchNewsException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected News removeImpl(News news) throws SystemException {
		news = toUnwrappedModel(news);

		Session session = null;

		try {
			session = openSession();

			BatchSessionUtil.delete(session, news);
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		clearCache(news);

		return news;
	}

	@Override
	public News updateImpl(itf.dut.edu.vn.model.News news, boolean merge)
		throws SystemException {
		news = toUnwrappedModel(news);

		boolean isNew = news.isNew();

		NewsModelImpl newsModelImpl = (NewsModelImpl)news;

		Session session = null;

		try {
			session = openSession();

			BatchSessionUtil.update(session, news, merge);

			news.setNew(false);
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew || !NewsModelImpl.COLUMN_BITMASK_ENABLED) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		EntityCacheUtil.putResult(NewsModelImpl.ENTITY_CACHE_ENABLED,
			NewsImpl.class, news.getPrimaryKey(), news);

		if (isNew) {
			FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_TITLE,
				new Object[] { news.getTitle() }, news);

			FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_CONTENTNEWS,
				new Object[] { news.getContentNews() }, news);

			FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_CATEGORYID,
				new Object[] { Long.valueOf(news.getCategoryId()) }, news);
		}
		else {
			if ((newsModelImpl.getColumnBitmask() &
					FINDER_PATH_FETCH_BY_TITLE.getColumnBitmask()) != 0) {
				Object[] args = new Object[] { newsModelImpl.getOriginalTitle() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_TITLE, args);
				FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_TITLE, args);

				FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_TITLE,
					new Object[] { news.getTitle() }, news);
			}

			if ((newsModelImpl.getColumnBitmask() &
					FINDER_PATH_FETCH_BY_CONTENTNEWS.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						newsModelImpl.getOriginalContentNews()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_CONTENTNEWS,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_CONTENTNEWS,
					args);

				FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_CONTENTNEWS,
					new Object[] { news.getContentNews() }, news);
			}

			if ((newsModelImpl.getColumnBitmask() &
					FINDER_PATH_FETCH_BY_CATEGORYID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						Long.valueOf(newsModelImpl.getOriginalCategoryId())
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_CATEGORYID,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_CATEGORYID,
					args);

				FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_CATEGORYID,
					new Object[] { Long.valueOf(news.getCategoryId()) }, news);
			}
		}

		return news;
	}

	protected News toUnwrappedModel(News news) {
		if (news instanceof NewsImpl) {
			return news;
		}

		NewsImpl newsImpl = new NewsImpl();

		newsImpl.setNew(news.isNew());
		newsImpl.setPrimaryKey(news.getPrimaryKey());

		newsImpl.setNewsId(news.getNewsId());
		newsImpl.setTitle(news.getTitle());
		newsImpl.setUrlImage(news.getUrlImage());
		newsImpl.setSummarize(news.getSummarize());
		newsImpl.setCreateDate(news.getCreateDate());
		newsImpl.setModifiedDate(news.getModifiedDate());
		newsImpl.setCategoryId(news.getCategoryId());
		newsImpl.setContentNews(news.getContentNews());
		newsImpl.setCountView(news.getCountView());
		newsImpl.setGroupId(news.getGroupId());
		newsImpl.setCompanyId(news.getCompanyId());
		newsImpl.setMainNews(news.isMainNews());
		newsImpl.setWriter(news.getWriter());

		return newsImpl;
	}

	/**
	 * Returns the news with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the news
	 * @return the news
	 * @throws com.liferay.portal.NoSuchModelException if a news with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public News findByPrimaryKey(Serializable primaryKey)
		throws NoSuchModelException, SystemException {
		return findByPrimaryKey(((Long)primaryKey).longValue());
	}

	/**
	 * Returns the news with the primary key or throws a {@link itf.dut.edu.vn.NoSuchNewsException} if it could not be found.
	 *
	 * @param newsId the primary key of the news
	 * @return the news
	 * @throws itf.dut.edu.vn.NoSuchNewsException if a news with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	public News findByPrimaryKey(long newsId)
		throws NoSuchNewsException, SystemException {
		News news = fetchByPrimaryKey(newsId);

		if (news == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + newsId);
			}

			throw new NoSuchNewsException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				newsId);
		}

		return news;
	}

	/**
	 * Returns the news with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the news
	 * @return the news, or <code>null</code> if a news with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public News fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		return fetchByPrimaryKey(((Long)primaryKey).longValue());
	}

	/**
	 * Returns the news with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param newsId the primary key of the news
	 * @return the news, or <code>null</code> if a news with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	public News fetchByPrimaryKey(long newsId) throws SystemException {
		News news = (News)EntityCacheUtil.getResult(NewsModelImpl.ENTITY_CACHE_ENABLED,
				NewsImpl.class, newsId);

		if (news == _nullNews) {
			return null;
		}

		if (news == null) {
			Session session = null;

			boolean hasException = false;

			try {
				session = openSession();

				news = (News)session.get(NewsImpl.class, Long.valueOf(newsId));
			}
			catch (Exception e) {
				hasException = true;

				throw processException(e);
			}
			finally {
				if (news != null) {
					cacheResult(news);
				}
				else if (!hasException) {
					EntityCacheUtil.putResult(NewsModelImpl.ENTITY_CACHE_ENABLED,
						NewsImpl.class, newsId, _nullNews);
				}

				closeSession(session);
			}
		}

		return news;
	}

	/**
	 * Returns the news where title = &#63; or throws a {@link itf.dut.edu.vn.NoSuchNewsException} if it could not be found.
	 *
	 * @param title the title
	 * @return the matching news
	 * @throws itf.dut.edu.vn.NoSuchNewsException if a matching news could not be found
	 * @throws SystemException if a system exception occurred
	 */
	public News findBytitle(String title)
		throws NoSuchNewsException, SystemException {
		News news = fetchBytitle(title);

		if (news == null) {
			StringBundler msg = new StringBundler(4);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("title=");
			msg.append(title);

			msg.append(StringPool.CLOSE_CURLY_BRACE);

			if (_log.isWarnEnabled()) {
				_log.warn(msg.toString());
			}

			throw new NoSuchNewsException(msg.toString());
		}

		return news;
	}

	/**
	 * Returns the news where title = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param title the title
	 * @return the matching news, or <code>null</code> if a matching news could not be found
	 * @throws SystemException if a system exception occurred
	 */
	public News fetchBytitle(String title) throws SystemException {
		return fetchBytitle(title, true);
	}

	/**
	 * Returns the news where title = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param title the title
	 * @param retrieveFromCache whether to use the finder cache
	 * @return the matching news, or <code>null</code> if a matching news could not be found
	 * @throws SystemException if a system exception occurred
	 */
	public News fetchBytitle(String title, boolean retrieveFromCache)
		throws SystemException {
		Object[] finderArgs = new Object[] { title };

		Object result = null;

		if (retrieveFromCache) {
			result = FinderCacheUtil.getResult(FINDER_PATH_FETCH_BY_TITLE,
					finderArgs, this);
		}

		if (result == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_SELECT_NEWS_WHERE);

			if (title == null) {
				query.append(_FINDER_COLUMN_TITLE_TITLE_1);
			}
			else {
				if (title.equals(StringPool.BLANK)) {
					query.append(_FINDER_COLUMN_TITLE_TITLE_3);
				}
				else {
					query.append(_FINDER_COLUMN_TITLE_TITLE_2);
				}
			}

			query.append(NewsModelImpl.ORDER_BY_JPQL);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (title != null) {
					qPos.add(title);
				}

				List<News> list = q.list();

				result = list;

				News news = null;

				if (list.isEmpty()) {
					FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_TITLE,
						finderArgs, list);
				}
				else {
					news = list.get(0);

					cacheResult(news);

					if ((news.getTitle() == null) ||
							!news.getTitle().equals(title)) {
						FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_TITLE,
							finderArgs, news);
					}
				}

				return news;
			}
			catch (Exception e) {
				throw processException(e);
			}
			finally {
				if (result == null) {
					FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_TITLE,
						finderArgs);
				}

				closeSession(session);
			}
		}
		else {
			if (result instanceof List<?>) {
				return null;
			}
			else {
				return (News)result;
			}
		}
	}

	/**
	 * Returns the news where contentNews = &#63; or throws a {@link itf.dut.edu.vn.NoSuchNewsException} if it could not be found.
	 *
	 * @param contentNews the content news
	 * @return the matching news
	 * @throws itf.dut.edu.vn.NoSuchNewsException if a matching news could not be found
	 * @throws SystemException if a system exception occurred
	 */
	public News findBycontentNews(String contentNews)
		throws NoSuchNewsException, SystemException {
		News news = fetchBycontentNews(contentNews);

		if (news == null) {
			StringBundler msg = new StringBundler(4);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("contentNews=");
			msg.append(contentNews);

			msg.append(StringPool.CLOSE_CURLY_BRACE);

			if (_log.isWarnEnabled()) {
				_log.warn(msg.toString());
			}

			throw new NoSuchNewsException(msg.toString());
		}

		return news;
	}

	/**
	 * Returns the news where contentNews = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param contentNews the content news
	 * @return the matching news, or <code>null</code> if a matching news could not be found
	 * @throws SystemException if a system exception occurred
	 */
	public News fetchBycontentNews(String contentNews)
		throws SystemException {
		return fetchBycontentNews(contentNews, true);
	}

	/**
	 * Returns the news where contentNews = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param contentNews the content news
	 * @param retrieveFromCache whether to use the finder cache
	 * @return the matching news, or <code>null</code> if a matching news could not be found
	 * @throws SystemException if a system exception occurred
	 */
	public News fetchBycontentNews(String contentNews, boolean retrieveFromCache)
		throws SystemException {
		Object[] finderArgs = new Object[] { contentNews };

		Object result = null;

		if (retrieveFromCache) {
			result = FinderCacheUtil.getResult(FINDER_PATH_FETCH_BY_CONTENTNEWS,
					finderArgs, this);
		}

		if (result == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_SELECT_NEWS_WHERE);

			if (contentNews == null) {
				query.append(_FINDER_COLUMN_CONTENTNEWS_CONTENTNEWS_1);
			}
			else {
				if (contentNews.equals(StringPool.BLANK)) {
					query.append(_FINDER_COLUMN_CONTENTNEWS_CONTENTNEWS_3);
				}
				else {
					query.append(_FINDER_COLUMN_CONTENTNEWS_CONTENTNEWS_2);
				}
			}

			query.append(NewsModelImpl.ORDER_BY_JPQL);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (contentNews != null) {
					qPos.add(contentNews);
				}

				List<News> list = q.list();

				result = list;

				News news = null;

				if (list.isEmpty()) {
					FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_CONTENTNEWS,
						finderArgs, list);
				}
				else {
					news = list.get(0);

					cacheResult(news);

					if ((news.getContentNews() == null) ||
							!news.getContentNews().equals(contentNews)) {
						FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_CONTENTNEWS,
							finderArgs, news);
					}
				}

				return news;
			}
			catch (Exception e) {
				throw processException(e);
			}
			finally {
				if (result == null) {
					FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_CONTENTNEWS,
						finderArgs);
				}

				closeSession(session);
			}
		}
		else {
			if (result instanceof List<?>) {
				return null;
			}
			else {
				return (News)result;
			}
		}
	}

	/**
	 * Returns the news where categoryId = &#63; or throws a {@link itf.dut.edu.vn.NoSuchNewsException} if it could not be found.
	 *
	 * @param categoryId the category ID
	 * @return the matching news
	 * @throws itf.dut.edu.vn.NoSuchNewsException if a matching news could not be found
	 * @throws SystemException if a system exception occurred
	 */
	public News findBycategoryId(long categoryId)
		throws NoSuchNewsException, SystemException {
		News news = fetchBycategoryId(categoryId);

		if (news == null) {
			StringBundler msg = new StringBundler(4);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("categoryId=");
			msg.append(categoryId);

			msg.append(StringPool.CLOSE_CURLY_BRACE);

			if (_log.isWarnEnabled()) {
				_log.warn(msg.toString());
			}

			throw new NoSuchNewsException(msg.toString());
		}

		return news;
	}

	/**
	 * Returns the news where categoryId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param categoryId the category ID
	 * @return the matching news, or <code>null</code> if a matching news could not be found
	 * @throws SystemException if a system exception occurred
	 */
	public News fetchBycategoryId(long categoryId) throws SystemException {
		return fetchBycategoryId(categoryId, true);
	}

	/**
	 * Returns the news where categoryId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param categoryId the category ID
	 * @param retrieveFromCache whether to use the finder cache
	 * @return the matching news, or <code>null</code> if a matching news could not be found
	 * @throws SystemException if a system exception occurred
	 */
	public News fetchBycategoryId(long categoryId, boolean retrieveFromCache)
		throws SystemException {
		Object[] finderArgs = new Object[] { categoryId };

		Object result = null;

		if (retrieveFromCache) {
			result = FinderCacheUtil.getResult(FINDER_PATH_FETCH_BY_CATEGORYID,
					finderArgs, this);
		}

		if (result == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_SELECT_NEWS_WHERE);

			query.append(_FINDER_COLUMN_CATEGORYID_CATEGORYID_2);

			query.append(NewsModelImpl.ORDER_BY_JPQL);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(categoryId);

				List<News> list = q.list();

				result = list;

				News news = null;

				if (list.isEmpty()) {
					FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_CATEGORYID,
						finderArgs, list);
				}
				else {
					news = list.get(0);

					cacheResult(news);

					if ((news.getCategoryId() != categoryId)) {
						FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_CATEGORYID,
							finderArgs, news);
					}
				}

				return news;
			}
			catch (Exception e) {
				throw processException(e);
			}
			finally {
				if (result == null) {
					FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_CATEGORYID,
						finderArgs);
				}

				closeSession(session);
			}
		}
		else {
			if (result instanceof List<?>) {
				return null;
			}
			else {
				return (News)result;
			}
		}
	}

	/**
	 * Returns all the newses.
	 *
	 * @return the newses
	 * @throws SystemException if a system exception occurred
	 */
	public List<News> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the newses.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set.
	 * </p>
	 *
	 * @param start the lower bound of the range of newses
	 * @param end the upper bound of the range of newses (not inclusive)
	 * @return the range of newses
	 * @throws SystemException if a system exception occurred
	 */
	public List<News> findAll(int start, int end) throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the newses.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set.
	 * </p>
	 *
	 * @param start the lower bound of the range of newses
	 * @param end the upper bound of the range of newses (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of newses
	 * @throws SystemException if a system exception occurred
	 */
	public List<News> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		FinderPath finderPath = null;
		Object[] finderArgs = new Object[] { start, end, orderByComparator };

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<News> list = (List<News>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_NEWS);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_NEWS.concat(NewsModelImpl.ORDER_BY_JPQL);
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (orderByComparator == null) {
					list = (List<News>)QueryUtil.list(q, getDialect(), start,
							end, false);

					Collections.sort(list);
				}
				else {
					list = (List<News>)QueryUtil.list(q, getDialect(), start,
							end);
				}
			}
			catch (Exception e) {
				throw processException(e);
			}
			finally {
				if (list == null) {
					FinderCacheUtil.removeResult(finderPath, finderArgs);
				}
				else {
					cacheResult(list);

					FinderCacheUtil.putResult(finderPath, finderArgs, list);
				}

				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes the news where title = &#63; from the database.
	 *
	 * @param title the title
	 * @throws SystemException if a system exception occurred
	 */
	public void removeBytitle(String title)
		throws NoSuchNewsException, SystemException {
		News news = findBytitle(title);

		remove(news);
	}

	/**
	 * Removes the news where contentNews = &#63; from the database.
	 *
	 * @param contentNews the content news
	 * @throws SystemException if a system exception occurred
	 */
	public void removeBycontentNews(String contentNews)
		throws NoSuchNewsException, SystemException {
		News news = findBycontentNews(contentNews);

		remove(news);
	}

	/**
	 * Removes the news where categoryId = &#63; from the database.
	 *
	 * @param categoryId the category ID
	 * @throws SystemException if a system exception occurred
	 */
	public void removeBycategoryId(long categoryId)
		throws NoSuchNewsException, SystemException {
		News news = findBycategoryId(categoryId);

		remove(news);
	}

	/**
	 * Removes all the newses from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	public void removeAll() throws SystemException {
		for (News news : findAll()) {
			remove(news);
		}
	}

	/**
	 * Returns the number of newses where title = &#63;.
	 *
	 * @param title the title
	 * @return the number of matching newses
	 * @throws SystemException if a system exception occurred
	 */
	public int countBytitle(String title) throws SystemException {
		Object[] finderArgs = new Object[] { title };

		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_BY_TITLE,
				finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_NEWS_WHERE);

			if (title == null) {
				query.append(_FINDER_COLUMN_TITLE_TITLE_1);
			}
			else {
				if (title.equals(StringPool.BLANK)) {
					query.append(_FINDER_COLUMN_TITLE_TITLE_3);
				}
				else {
					query.append(_FINDER_COLUMN_TITLE_TITLE_2);
				}
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (title != null) {
					qPos.add(title);
				}

				count = (Long)q.uniqueResult();
			}
			catch (Exception e) {
				throw processException(e);
			}
			finally {
				if (count == null) {
					count = Long.valueOf(0);
				}

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_TITLE,
					finderArgs, count);

				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Returns the number of newses where contentNews = &#63;.
	 *
	 * @param contentNews the content news
	 * @return the number of matching newses
	 * @throws SystemException if a system exception occurred
	 */
	public int countBycontentNews(String contentNews) throws SystemException {
		Object[] finderArgs = new Object[] { contentNews };

		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_BY_CONTENTNEWS,
				finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_NEWS_WHERE);

			if (contentNews == null) {
				query.append(_FINDER_COLUMN_CONTENTNEWS_CONTENTNEWS_1);
			}
			else {
				if (contentNews.equals(StringPool.BLANK)) {
					query.append(_FINDER_COLUMN_CONTENTNEWS_CONTENTNEWS_3);
				}
				else {
					query.append(_FINDER_COLUMN_CONTENTNEWS_CONTENTNEWS_2);
				}
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (contentNews != null) {
					qPos.add(contentNews);
				}

				count = (Long)q.uniqueResult();
			}
			catch (Exception e) {
				throw processException(e);
			}
			finally {
				if (count == null) {
					count = Long.valueOf(0);
				}

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_CONTENTNEWS,
					finderArgs, count);

				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Returns the number of newses where categoryId = &#63;.
	 *
	 * @param categoryId the category ID
	 * @return the number of matching newses
	 * @throws SystemException if a system exception occurred
	 */
	public int countBycategoryId(long categoryId) throws SystemException {
		Object[] finderArgs = new Object[] { categoryId };

		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_BY_CATEGORYID,
				finderArgs, this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_NEWS_WHERE);

			query.append(_FINDER_COLUMN_CATEGORYID_CATEGORYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(categoryId);

				count = (Long)q.uniqueResult();
			}
			catch (Exception e) {
				throw processException(e);
			}
			finally {
				if (count == null) {
					count = Long.valueOf(0);
				}

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_CATEGORYID,
					finderArgs, count);

				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Returns the number of newses.
	 *
	 * @return the number of newses
	 * @throws SystemException if a system exception occurred
	 */
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_NEWS);

				count = (Long)q.uniqueResult();
			}
			catch (Exception e) {
				throw processException(e);
			}
			finally {
				if (count == null) {
					count = Long.valueOf(0);
				}

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);

				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Initializes the news persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.itf.dut.edu.vn.model.News")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<News>> listenersList = new ArrayList<ModelListener<News>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<News>)InstanceFactory.newInstance(
							listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(NewsImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@BeanReference(type = AdvertisePersistence.class)
	protected AdvertisePersistence advertisePersistence;
	@BeanReference(type = CategoryPersistence.class)
	protected CategoryPersistence categoryPersistence;
	@BeanReference(type = CommentPersistence.class)
	protected CommentPersistence commentPersistence;
	@BeanReference(type = GoodSentencesPersistence.class)
	protected GoodSentencesPersistence goodSentencesPersistence;
	@BeanReference(type = NewsPersistence.class)
	protected NewsPersistence newsPersistence;
	@BeanReference(type = ResourcePersistence.class)
	protected ResourcePersistence resourcePersistence;
	@BeanReference(type = UserPersistence.class)
	protected UserPersistence userPersistence;
	private static final String _SQL_SELECT_NEWS = "SELECT news FROM News news";
	private static final String _SQL_SELECT_NEWS_WHERE = "SELECT news FROM News news WHERE ";
	private static final String _SQL_COUNT_NEWS = "SELECT COUNT(news) FROM News news";
	private static final String _SQL_COUNT_NEWS_WHERE = "SELECT COUNT(news) FROM News news WHERE ";
	private static final String _FINDER_COLUMN_TITLE_TITLE_1 = "news.title IS NULL";
	private static final String _FINDER_COLUMN_TITLE_TITLE_2 = "news.title = ?";
	private static final String _FINDER_COLUMN_TITLE_TITLE_3 = "(news.title IS NULL OR news.title = ?)";
	private static final String _FINDER_COLUMN_CONTENTNEWS_CONTENTNEWS_1 = "news.contentNews IS NULL";
	private static final String _FINDER_COLUMN_CONTENTNEWS_CONTENTNEWS_2 = "news.contentNews = ?";
	private static final String _FINDER_COLUMN_CONTENTNEWS_CONTENTNEWS_3 = "(news.contentNews IS NULL OR news.contentNews = ?)";
	private static final String _FINDER_COLUMN_CATEGORYID_CATEGORYID_2 = "news.categoryId = ?";
	private static final String _ORDER_BY_ENTITY_ALIAS = "news.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No News exists with the primary key ";
	private static final String _NO_SUCH_ENTITY_WITH_KEY = "No News exists with the key {";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(NewsPersistenceImpl.class);
	private static News _nullNews = new NewsImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<News> toCacheModel() {
				return _nullNewsCacheModel;
			}
		};

	private static CacheModel<News> _nullNewsCacheModel = new CacheModel<News>() {
			public News toEntityModel() {
				return _nullNews;
			}
		};
}