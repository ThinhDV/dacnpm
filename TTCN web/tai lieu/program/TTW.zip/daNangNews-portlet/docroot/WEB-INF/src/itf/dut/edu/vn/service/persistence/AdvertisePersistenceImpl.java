/**
 * Copyright (c) 2000-2012 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package itf.dut.edu.vn.service.persistence;

import com.liferay.portal.NoSuchModelException;
import com.liferay.portal.kernel.bean.BeanReference;
import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.BatchSessionUtil;
import com.liferay.portal.service.persistence.ResourcePersistence;
import com.liferay.portal.service.persistence.UserPersistence;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import itf.dut.edu.vn.NoSuchAdvertiseException;
import itf.dut.edu.vn.model.Advertise;
import itf.dut.edu.vn.model.impl.AdvertiseImpl;
import itf.dut.edu.vn.model.impl.AdvertiseModelImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The persistence implementation for the advertise service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author thanhlikes09
 * @see AdvertisePersistence
 * @see AdvertiseUtil
 * @generated
 */
public class AdvertisePersistenceImpl extends BasePersistenceImpl<Advertise>
	implements AdvertisePersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link AdvertiseUtil} to access the advertise persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = AdvertiseImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(AdvertiseModelImpl.ENTITY_CACHE_ENABLED,
			AdvertiseModelImpl.FINDER_CACHE_ENABLED, AdvertiseImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(AdvertiseModelImpl.ENTITY_CACHE_ENABLED,
			AdvertiseModelImpl.FINDER_CACHE_ENABLED, AdvertiseImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(AdvertiseModelImpl.ENTITY_CACHE_ENABLED,
			AdvertiseModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);

	/**
	 * Caches the advertise in the entity cache if it is enabled.
	 *
	 * @param advertise the advertise
	 */
	public void cacheResult(Advertise advertise) {
		EntityCacheUtil.putResult(AdvertiseModelImpl.ENTITY_CACHE_ENABLED,
			AdvertiseImpl.class, advertise.getPrimaryKey(), advertise);

		advertise.resetOriginalValues();
	}

	/**
	 * Caches the advertises in the entity cache if it is enabled.
	 *
	 * @param advertises the advertises
	 */
	public void cacheResult(List<Advertise> advertises) {
		for (Advertise advertise : advertises) {
			if (EntityCacheUtil.getResult(
						AdvertiseModelImpl.ENTITY_CACHE_ENABLED,
						AdvertiseImpl.class, advertise.getPrimaryKey()) == null) {
				cacheResult(advertise);
			}
			else {
				advertise.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all advertises.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(AdvertiseImpl.class.getName());
		}

		EntityCacheUtil.clearCache(AdvertiseImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the advertise.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(Advertise advertise) {
		EntityCacheUtil.removeResult(AdvertiseModelImpl.ENTITY_CACHE_ENABLED,
			AdvertiseImpl.class, advertise.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	public void clearCache(List<Advertise> advertises) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (Advertise advertise : advertises) {
			EntityCacheUtil.removeResult(AdvertiseModelImpl.ENTITY_CACHE_ENABLED,
				AdvertiseImpl.class, advertise.getPrimaryKey());
		}
	}

	/**
	 * Creates a new advertise with the primary key. Does not add the advertise to the database.
	 *
	 * @param advertiseId the primary key for the new advertise
	 * @return the new advertise
	 */
	public Advertise create(long advertiseId) {
		Advertise advertise = new AdvertiseImpl();

		advertise.setNew(true);
		advertise.setPrimaryKey(advertiseId);

		return advertise;
	}

	/**
	 * Removes the advertise with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param advertiseId the primary key of the advertise
	 * @return the advertise that was removed
	 * @throws itf.dut.edu.vn.NoSuchAdvertiseException if a advertise with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	public Advertise remove(long advertiseId)
		throws NoSuchAdvertiseException, SystemException {
		return remove(Long.valueOf(advertiseId));
	}

	/**
	 * Removes the advertise with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the advertise
	 * @return the advertise that was removed
	 * @throws itf.dut.edu.vn.NoSuchAdvertiseException if a advertise with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Advertise remove(Serializable primaryKey)
		throws NoSuchAdvertiseException, SystemException {
		Session session = null;

		try {
			session = openSession();

			Advertise advertise = (Advertise)session.get(AdvertiseImpl.class,
					primaryKey);

			if (advertise == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchAdvertiseException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(advertise);
		}
		catch (NoSuchAdvertiseException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected Advertise removeImpl(Advertise advertise)
		throws SystemException {
		advertise = toUnwrappedModel(advertise);

		Session session = null;

		try {
			session = openSession();

			BatchSessionUtil.delete(session, advertise);
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		clearCache(advertise);

		return advertise;
	}

	@Override
	public Advertise updateImpl(itf.dut.edu.vn.model.Advertise advertise,
		boolean merge) throws SystemException {
		advertise = toUnwrappedModel(advertise);

		Session session = null;

		try {
			session = openSession();

			BatchSessionUtil.update(session, advertise, merge);

			advertise.setNew(false);
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		EntityCacheUtil.putResult(AdvertiseModelImpl.ENTITY_CACHE_ENABLED,
			AdvertiseImpl.class, advertise.getPrimaryKey(), advertise);

		return advertise;
	}

	protected Advertise toUnwrappedModel(Advertise advertise) {
		if (advertise instanceof AdvertiseImpl) {
			return advertise;
		}

		AdvertiseImpl advertiseImpl = new AdvertiseImpl();

		advertiseImpl.setNew(advertise.isNew());
		advertiseImpl.setPrimaryKey(advertise.getPrimaryKey());

		advertiseImpl.setAdvertiseId(advertise.getAdvertiseId());
		advertiseImpl.setDescribe(advertise.getDescribe());
		advertiseImpl.setUrl(advertise.getUrl());
		advertiseImpl.setUrlImage(advertise.getUrlImage());
		advertiseImpl.setCountClick(advertise.getCountClick());
		advertiseImpl.setHide(advertise.isHide());
		advertiseImpl.setGroupId(advertise.getGroupId());
		advertiseImpl.setCompanyId(advertise.getCompanyId());

		return advertiseImpl;
	}

	/**
	 * Returns the advertise with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the advertise
	 * @return the advertise
	 * @throws com.liferay.portal.NoSuchModelException if a advertise with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Advertise findByPrimaryKey(Serializable primaryKey)
		throws NoSuchModelException, SystemException {
		return findByPrimaryKey(((Long)primaryKey).longValue());
	}

	/**
	 * Returns the advertise with the primary key or throws a {@link itf.dut.edu.vn.NoSuchAdvertiseException} if it could not be found.
	 *
	 * @param advertiseId the primary key of the advertise
	 * @return the advertise
	 * @throws itf.dut.edu.vn.NoSuchAdvertiseException if a advertise with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	public Advertise findByPrimaryKey(long advertiseId)
		throws NoSuchAdvertiseException, SystemException {
		Advertise advertise = fetchByPrimaryKey(advertiseId);

		if (advertise == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + advertiseId);
			}

			throw new NoSuchAdvertiseException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				advertiseId);
		}

		return advertise;
	}

	/**
	 * Returns the advertise with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the advertise
	 * @return the advertise, or <code>null</code> if a advertise with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Advertise fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		return fetchByPrimaryKey(((Long)primaryKey).longValue());
	}

	/**
	 * Returns the advertise with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param advertiseId the primary key of the advertise
	 * @return the advertise, or <code>null</code> if a advertise with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	public Advertise fetchByPrimaryKey(long advertiseId)
		throws SystemException {
		Advertise advertise = (Advertise)EntityCacheUtil.getResult(AdvertiseModelImpl.ENTITY_CACHE_ENABLED,
				AdvertiseImpl.class, advertiseId);

		if (advertise == _nullAdvertise) {
			return null;
		}

		if (advertise == null) {
			Session session = null;

			boolean hasException = false;

			try {
				session = openSession();

				advertise = (Advertise)session.get(AdvertiseImpl.class,
						Long.valueOf(advertiseId));
			}
			catch (Exception e) {
				hasException = true;

				throw processException(e);
			}
			finally {
				if (advertise != null) {
					cacheResult(advertise);
				}
				else if (!hasException) {
					EntityCacheUtil.putResult(AdvertiseModelImpl.ENTITY_CACHE_ENABLED,
						AdvertiseImpl.class, advertiseId, _nullAdvertise);
				}

				closeSession(session);
			}
		}

		return advertise;
	}

	/**
	 * Returns all the advertises.
	 *
	 * @return the advertises
	 * @throws SystemException if a system exception occurred
	 */
	public List<Advertise> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the advertises.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set.
	 * </p>
	 *
	 * @param start the lower bound of the range of advertises
	 * @param end the upper bound of the range of advertises (not inclusive)
	 * @return the range of advertises
	 * @throws SystemException if a system exception occurred
	 */
	public List<Advertise> findAll(int start, int end)
		throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the advertises.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set.
	 * </p>
	 *
	 * @param start the lower bound of the range of advertises
	 * @param end the upper bound of the range of advertises (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of advertises
	 * @throws SystemException if a system exception occurred
	 */
	public List<Advertise> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		FinderPath finderPath = null;
		Object[] finderArgs = new Object[] { start, end, orderByComparator };

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<Advertise> list = (List<Advertise>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_ADVERTISE);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_ADVERTISE.concat(AdvertiseModelImpl.ORDER_BY_JPQL);
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (orderByComparator == null) {
					list = (List<Advertise>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);
				}
				else {
					list = (List<Advertise>)QueryUtil.list(q, getDialect(),
							start, end);
				}
			}
			catch (Exception e) {
				throw processException(e);
			}
			finally {
				if (list == null) {
					FinderCacheUtil.removeResult(finderPath, finderArgs);
				}
				else {
					cacheResult(list);

					FinderCacheUtil.putResult(finderPath, finderArgs, list);
				}

				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the advertises from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	public void removeAll() throws SystemException {
		for (Advertise advertise : findAll()) {
			remove(advertise);
		}
	}

	/**
	 * Returns the number of advertises.
	 *
	 * @return the number of advertises
	 * @throws SystemException if a system exception occurred
	 */
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_ADVERTISE);

				count = (Long)q.uniqueResult();
			}
			catch (Exception e) {
				throw processException(e);
			}
			finally {
				if (count == null) {
					count = Long.valueOf(0);
				}

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);

				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Initializes the advertise persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.itf.dut.edu.vn.model.Advertise")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<Advertise>> listenersList = new ArrayList<ModelListener<Advertise>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<Advertise>)InstanceFactory.newInstance(
							listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(AdvertiseImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@BeanReference(type = AdvertisePersistence.class)
	protected AdvertisePersistence advertisePersistence;
	@BeanReference(type = CategoryPersistence.class)
	protected CategoryPersistence categoryPersistence;
	@BeanReference(type = CommentPersistence.class)
	protected CommentPersistence commentPersistence;
	@BeanReference(type = GoodSentencesPersistence.class)
	protected GoodSentencesPersistence goodSentencesPersistence;
	@BeanReference(type = NewsPersistence.class)
	protected NewsPersistence newsPersistence;
	@BeanReference(type = ResourcePersistence.class)
	protected ResourcePersistence resourcePersistence;
	@BeanReference(type = UserPersistence.class)
	protected UserPersistence userPersistence;
	private static final String _SQL_SELECT_ADVERTISE = "SELECT advertise FROM Advertise advertise";
	private static final String _SQL_COUNT_ADVERTISE = "SELECT COUNT(advertise) FROM Advertise advertise";
	private static final String _ORDER_BY_ENTITY_ALIAS = "advertise.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No Advertise exists with the primary key ";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(AdvertisePersistenceImpl.class);
	private static Advertise _nullAdvertise = new AdvertiseImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<Advertise> toCacheModel() {
				return _nullAdvertiseCacheModel;
			}
		};

	private static CacheModel<Advertise> _nullAdvertiseCacheModel = new CacheModel<Advertise>() {
			public Advertise toEntityModel() {
				return _nullAdvertise;
			}
		};
}