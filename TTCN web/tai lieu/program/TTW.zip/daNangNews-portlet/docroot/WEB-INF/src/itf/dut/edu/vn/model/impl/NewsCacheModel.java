/**
 * Copyright (c) 2000-2012 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package itf.dut.edu.vn.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import itf.dut.edu.vn.model.News;

import java.io.Serializable;

import java.util.Date;

/**
 * The cache model class for representing News in entity cache.
 *
 * @author thanhlikes09
 * @see News
 * @generated
 */
public class NewsCacheModel implements CacheModel<News>, Serializable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(27);

		sb.append("{newsId=");
		sb.append(newsId);
		sb.append(", title=");
		sb.append(title);
		sb.append(", urlImage=");
		sb.append(urlImage);
		sb.append(", summarize=");
		sb.append(summarize);
		sb.append(", createDate=");
		sb.append(createDate);
		sb.append(", modifiedDate=");
		sb.append(modifiedDate);
		sb.append(", categoryId=");
		sb.append(categoryId);
		sb.append(", contentNews=");
		sb.append(contentNews);
		sb.append(", countView=");
		sb.append(countView);
		sb.append(", groupId=");
		sb.append(groupId);
		sb.append(", companyId=");
		sb.append(companyId);
		sb.append(", mainNews=");
		sb.append(mainNews);
		sb.append(", writer=");
		sb.append(writer);
		sb.append("}");

		return sb.toString();
	}

	public News toEntityModel() {
		NewsImpl newsImpl = new NewsImpl();

		newsImpl.setNewsId(newsId);

		if (title == null) {
			newsImpl.setTitle(StringPool.BLANK);
		}
		else {
			newsImpl.setTitle(title);
		}

		if (urlImage == null) {
			newsImpl.setUrlImage(StringPool.BLANK);
		}
		else {
			newsImpl.setUrlImage(urlImage);
		}

		if (summarize == null) {
			newsImpl.setSummarize(StringPool.BLANK);
		}
		else {
			newsImpl.setSummarize(summarize);
		}

		if (createDate == Long.MIN_VALUE) {
			newsImpl.setCreateDate(null);
		}
		else {
			newsImpl.setCreateDate(new Date(createDate));
		}

		if (modifiedDate == Long.MIN_VALUE) {
			newsImpl.setModifiedDate(null);
		}
		else {
			newsImpl.setModifiedDate(new Date(modifiedDate));
		}

		newsImpl.setCategoryId(categoryId);

		if (contentNews == null) {
			newsImpl.setContentNews(StringPool.BLANK);
		}
		else {
			newsImpl.setContentNews(contentNews);
		}

		newsImpl.setCountView(countView);
		newsImpl.setGroupId(groupId);
		newsImpl.setCompanyId(companyId);
		newsImpl.setMainNews(mainNews);

		if (writer == null) {
			newsImpl.setWriter(StringPool.BLANK);
		}
		else {
			newsImpl.setWriter(writer);
		}

		newsImpl.resetOriginalValues();

		return newsImpl;
	}

	public long newsId;
	public String title;
	public String urlImage;
	public String summarize;
	public long createDate;
	public long modifiedDate;
	public long categoryId;
	public String contentNews;
	public long countView;
	public long groupId;
	public long companyId;
	public boolean mainNews;
	public String writer;
}