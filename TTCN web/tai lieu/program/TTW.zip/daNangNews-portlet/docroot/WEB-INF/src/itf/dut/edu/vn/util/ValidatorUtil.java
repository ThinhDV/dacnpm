package itf.dut.edu.vn.util;

import itf.dut.edu.vn.model.GoodSentences;

import java.util.List;

import com.liferay.portal.kernel.util.Validator;

public class ValidatorUtil {
	public static boolean validateGoodSentences(GoodSentences goodSentences, List errors) 
	{
        boolean valid = true;

        if (Validator.isNull(goodSentences.getSentence())) {
            errors.add("name-required");
            valid = false;
        }   
        return valid;
    }
}
