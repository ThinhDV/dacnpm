create table TTH_Advertise (
	advertiseId LONG not null primary key,
	describe VARCHAR(75) null,
	url VARCHAR(75) null,
	urlImage VARCHAR(75) null,
	countClick LONG,
	hide BOOLEAN,
	groupId LONG,
	companyId LONG
);

create table TTH_Category (
	categoryId LONG not null primary key,
	nameCategory VARCHAR(75) null,
	groupId LONG,
	companyId LONG
);

create table TTH_Comment (
	commentId LONG not null primary key,
	newsId LONG,
	name VARCHAR(75) null,
	email VARCHAR(75) null,
	address VARCHAR(75) null,
	title VARCHAR(75) null,
	contentComment VARCHAR(75) null,
	createDate DATE null,
	groupId LONG,
	companyId LONG
);

create table TTH_GoodSentences (
	sentenceId INTEGER not null primary key,
	sentence VARCHAR(75) null,
	day INTEGER,
	groupId LONG,
	companyId LONG
);

create table TTH_News (
	newsId LONG not null primary key,
	title VARCHAR(75) null,
	urlImage VARCHAR(75) null,
	summarize VARCHAR(75) null,
	createDate DATE null,
	modifiedDate DATE null,
	categoryId LONG,
	contentNews VARCHAR(75) null,
	countView LONG,
	groupId LONG,
	companyId LONG,
	mainNews BOOLEAN,
	writer VARCHAR(75) null
);