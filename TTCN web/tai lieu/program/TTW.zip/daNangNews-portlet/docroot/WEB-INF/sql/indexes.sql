create index IX_DF0CB958 on TTH_Category (nameCategory);

create index IX_2C8E61D0 on TTH_Comment (newsId);

create index IX_E8FEEA48 on TTH_GoodSentences (groupId);

create index IX_473BA73D on TTH_News (categoryId);
create index IX_70780DCC on TTH_News (contentNews);
create index IX_B0BE50B8 on TTH_News (title);