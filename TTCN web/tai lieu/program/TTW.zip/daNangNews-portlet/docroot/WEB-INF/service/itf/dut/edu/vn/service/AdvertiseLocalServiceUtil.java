/**
 * Copyright (c) 2000-2012 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package itf.dut.edu.vn.service;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.util.ClassLoaderProxy;
import com.liferay.portal.kernel.util.MethodCache;
import com.liferay.portal.kernel.util.ReferenceRegistry;

/**
 * The utility for the advertise local service. This utility wraps {@link itf.dut.edu.vn.service.impl.AdvertiseLocalServiceImpl} and is the primary access point for service operations in application layer code running on the local server.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author thanhlikes09
 * @see AdvertiseLocalService
 * @see itf.dut.edu.vn.service.base.AdvertiseLocalServiceBaseImpl
 * @see itf.dut.edu.vn.service.impl.AdvertiseLocalServiceImpl
 * @generated
 */
public class AdvertiseLocalServiceUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Add custom service methods to {@link itf.dut.edu.vn.service.impl.AdvertiseLocalServiceImpl} and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	* Adds the advertise to the database. Also notifies the appropriate model listeners.
	*
	* @param advertise the advertise
	* @return the advertise that was added
	* @throws SystemException if a system exception occurred
	*/
	public static itf.dut.edu.vn.model.Advertise addAdvertise(
		itf.dut.edu.vn.model.Advertise advertise)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().addAdvertise(advertise);
	}

	/**
	* Creates a new advertise with the primary key. Does not add the advertise to the database.
	*
	* @param advertiseId the primary key for the new advertise
	* @return the new advertise
	*/
	public static itf.dut.edu.vn.model.Advertise createAdvertise(
		long advertiseId) {
		return getService().createAdvertise(advertiseId);
	}

	/**
	* Deletes the advertise with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param advertiseId the primary key of the advertise
	* @throws PortalException if a advertise with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static void deleteAdvertise(long advertiseId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		getService().deleteAdvertise(advertiseId);
	}

	/**
	* Deletes the advertise from the database. Also notifies the appropriate model listeners.
	*
	* @param advertise the advertise
	* @throws SystemException if a system exception occurred
	*/
	public static void deleteAdvertise(itf.dut.edu.vn.model.Advertise advertise)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().deleteAdvertise(advertise);
	}

	/**
	* Performs a dynamic query on the database and returns the matching rows.
	*
	* @param dynamicQuery the dynamic query
	* @return the matching rows
	* @throws SystemException if a system exception occurred
	*/
	@SuppressWarnings("rawtypes")
	public static java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQuery(dynamicQuery);
	}

	/**
	* Performs a dynamic query on the database and returns a range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @return the range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@SuppressWarnings("rawtypes")
	public static java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQuery(dynamicQuery, start, end);
	}

	/**
	* Performs a dynamic query on the database and returns an ordered range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@SuppressWarnings("rawtypes")
	public static java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService()
				   .dynamicQuery(dynamicQuery, start, end, orderByComparator);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	public static long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQueryCount(dynamicQuery);
	}

	public static itf.dut.edu.vn.model.Advertise fetchAdvertise(
		long advertiseId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().fetchAdvertise(advertiseId);
	}

	/**
	* Returns the advertise with the primary key.
	*
	* @param advertiseId the primary key of the advertise
	* @return the advertise
	* @throws PortalException if a advertise with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static itf.dut.edu.vn.model.Advertise getAdvertise(long advertiseId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().getAdvertise(advertiseId);
	}

	public static com.liferay.portal.model.PersistedModel getPersistedModel(
		java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().getPersistedModel(primaryKeyObj);
	}

	/**
	* Returns a range of all the advertises.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set.
	* </p>
	*
	* @param start the lower bound of the range of advertises
	* @param end the upper bound of the range of advertises (not inclusive)
	* @return the range of advertises
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<itf.dut.edu.vn.model.Advertise> getAdvertises(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getAdvertises(start, end);
	}

	/**
	* Returns the number of advertises.
	*
	* @return the number of advertises
	* @throws SystemException if a system exception occurred
	*/
	public static int getAdvertisesCount()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getAdvertisesCount();
	}

	/**
	* Updates the advertise in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	*
	* @param advertise the advertise
	* @return the advertise that was updated
	* @throws SystemException if a system exception occurred
	*/
	public static itf.dut.edu.vn.model.Advertise updateAdvertise(
		itf.dut.edu.vn.model.Advertise advertise)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().updateAdvertise(advertise);
	}

	/**
	* Updates the advertise in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	*
	* @param advertise the advertise
	* @param merge whether to merge the advertise with the current session. See {@link com.liferay.portal.service.persistence.BatchSession#update(com.liferay.portal.kernel.dao.orm.Session, com.liferay.portal.model.BaseModel, boolean)} for an explanation.
	* @return the advertise that was updated
	* @throws SystemException if a system exception occurred
	*/
	public static itf.dut.edu.vn.model.Advertise updateAdvertise(
		itf.dut.edu.vn.model.Advertise advertise, boolean merge)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().updateAdvertise(advertise, merge);
	}

	/**
	* Returns the Spring bean ID for this bean.
	*
	* @return the Spring bean ID for this bean
	*/
	public static java.lang.String getBeanIdentifier() {
		return getService().getBeanIdentifier();
	}

	/**
	* Sets the Spring bean ID for this bean.
	*
	* @param beanIdentifier the Spring bean ID for this bean
	*/
	public static void setBeanIdentifier(java.lang.String beanIdentifier) {
		getService().setBeanIdentifier(beanIdentifier);
	}

	public static void clearService() {
		_service = null;
	}

	public static AdvertiseLocalService getService() {
		if (_service == null) {
			Object object = PortletBeanLocatorUtil.locate(ClpSerializer.getServletContextName(),
					AdvertiseLocalService.class.getName());
			ClassLoader portletClassLoader = (ClassLoader)PortletBeanLocatorUtil.locate(ClpSerializer.getServletContextName(),
					"portletClassLoader");

			ClassLoaderProxy classLoaderProxy = new ClassLoaderProxy(object,
					AdvertiseLocalService.class.getName(), portletClassLoader);

			_service = new AdvertiseLocalServiceClp(classLoaderProxy);

			ClpSerializer.setClassLoader(portletClassLoader);

			ReferenceRegistry.registerReference(AdvertiseLocalServiceUtil.class,
				"_service");
			MethodCache.remove(AdvertiseLocalService.class);
		}

		return _service;
	}

	public void setService(AdvertiseLocalService service) {
		MethodCache.remove(AdvertiseLocalService.class);

		_service = service;

		ReferenceRegistry.registerReference(AdvertiseLocalServiceUtil.class,
			"_service");
		MethodCache.remove(AdvertiseLocalService.class);
	}

	private static AdvertiseLocalService _service;
}