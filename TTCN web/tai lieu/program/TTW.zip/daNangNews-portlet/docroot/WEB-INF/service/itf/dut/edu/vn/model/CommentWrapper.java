/**
 * Copyright (c) 2000-2012 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package itf.dut.edu.vn.model;

import com.liferay.portal.model.ModelWrapper;

/**
 * <p>
 * This class is a wrapper for {@link Comment}.
 * </p>
 *
 * @author    thanhlikes09
 * @see       Comment
 * @generated
 */
public class CommentWrapper implements Comment, ModelWrapper<Comment> {
	public CommentWrapper(Comment comment) {
		_comment = comment;
	}

	public Class<?> getModelClass() {
		return Comment.class;
	}

	public String getModelClassName() {
		return Comment.class.getName();
	}

	/**
	* Returns the primary key of this comment.
	*
	* @return the primary key of this comment
	*/
	public long getPrimaryKey() {
		return _comment.getPrimaryKey();
	}

	/**
	* Sets the primary key of this comment.
	*
	* @param primaryKey the primary key of this comment
	*/
	public void setPrimaryKey(long primaryKey) {
		_comment.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the comment ID of this comment.
	*
	* @return the comment ID of this comment
	*/
	public long getCommentId() {
		return _comment.getCommentId();
	}

	/**
	* Sets the comment ID of this comment.
	*
	* @param commentId the comment ID of this comment
	*/
	public void setCommentId(long commentId) {
		_comment.setCommentId(commentId);
	}

	/**
	* Returns the news ID of this comment.
	*
	* @return the news ID of this comment
	*/
	public long getNewsId() {
		return _comment.getNewsId();
	}

	/**
	* Sets the news ID of this comment.
	*
	* @param newsId the news ID of this comment
	*/
	public void setNewsId(long newsId) {
		_comment.setNewsId(newsId);
	}

	/**
	* Returns the name of this comment.
	*
	* @return the name of this comment
	*/
	public java.lang.String getName() {
		return _comment.getName();
	}

	/**
	* Sets the name of this comment.
	*
	* @param name the name of this comment
	*/
	public void setName(java.lang.String name) {
		_comment.setName(name);
	}

	/**
	* Returns the email of this comment.
	*
	* @return the email of this comment
	*/
	public java.lang.String getEmail() {
		return _comment.getEmail();
	}

	/**
	* Sets the email of this comment.
	*
	* @param email the email of this comment
	*/
	public void setEmail(java.lang.String email) {
		_comment.setEmail(email);
	}

	/**
	* Returns the address of this comment.
	*
	* @return the address of this comment
	*/
	public java.lang.String getAddress() {
		return _comment.getAddress();
	}

	/**
	* Sets the address of this comment.
	*
	* @param address the address of this comment
	*/
	public void setAddress(java.lang.String address) {
		_comment.setAddress(address);
	}

	/**
	* Returns the title of this comment.
	*
	* @return the title of this comment
	*/
	public java.lang.String getTitle() {
		return _comment.getTitle();
	}

	/**
	* Sets the title of this comment.
	*
	* @param title the title of this comment
	*/
	public void setTitle(java.lang.String title) {
		_comment.setTitle(title);
	}

	/**
	* Returns the content comment of this comment.
	*
	* @return the content comment of this comment
	*/
	public java.lang.String getContentComment() {
		return _comment.getContentComment();
	}

	/**
	* Sets the content comment of this comment.
	*
	* @param contentComment the content comment of this comment
	*/
	public void setContentComment(java.lang.String contentComment) {
		_comment.setContentComment(contentComment);
	}

	/**
	* Returns the create date of this comment.
	*
	* @return the create date of this comment
	*/
	public java.util.Date getCreateDate() {
		return _comment.getCreateDate();
	}

	/**
	* Sets the create date of this comment.
	*
	* @param createDate the create date of this comment
	*/
	public void setCreateDate(java.util.Date createDate) {
		_comment.setCreateDate(createDate);
	}

	/**
	* Returns the group ID of this comment.
	*
	* @return the group ID of this comment
	*/
	public long getGroupId() {
		return _comment.getGroupId();
	}

	/**
	* Sets the group ID of this comment.
	*
	* @param groupId the group ID of this comment
	*/
	public void setGroupId(long groupId) {
		_comment.setGroupId(groupId);
	}

	/**
	* Returns the company ID of this comment.
	*
	* @return the company ID of this comment
	*/
	public long getCompanyId() {
		return _comment.getCompanyId();
	}

	/**
	* Sets the company ID of this comment.
	*
	* @param companyId the company ID of this comment
	*/
	public void setCompanyId(long companyId) {
		_comment.setCompanyId(companyId);
	}

	public boolean isNew() {
		return _comment.isNew();
	}

	public void setNew(boolean n) {
		_comment.setNew(n);
	}

	public boolean isCachedModel() {
		return _comment.isCachedModel();
	}

	public void setCachedModel(boolean cachedModel) {
		_comment.setCachedModel(cachedModel);
	}

	public boolean isEscapedModel() {
		return _comment.isEscapedModel();
	}

	public java.io.Serializable getPrimaryKeyObj() {
		return _comment.getPrimaryKeyObj();
	}

	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_comment.setPrimaryKeyObj(primaryKeyObj);
	}

	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _comment.getExpandoBridge();
	}

	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_comment.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new CommentWrapper((Comment)_comment.clone());
	}

	public int compareTo(itf.dut.edu.vn.model.Comment comment) {
		return _comment.compareTo(comment);
	}

	@Override
	public int hashCode() {
		return _comment.hashCode();
	}

	public com.liferay.portal.model.CacheModel<itf.dut.edu.vn.model.Comment> toCacheModel() {
		return _comment.toCacheModel();
	}

	public itf.dut.edu.vn.model.Comment toEscapedModel() {
		return new CommentWrapper(_comment.toEscapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _comment.toString();
	}

	public java.lang.String toXmlString() {
		return _comment.toXmlString();
	}

	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_comment.persist();
	}

	/**
	 * @deprecated Renamed to {@link #getWrappedModel}
	 */
	public Comment getWrappedComment() {
		return _comment;
	}

	public Comment getWrappedModel() {
		return _comment;
	}

	public void resetOriginalValues() {
		_comment.resetOriginalValues();
	}

	private Comment _comment;
}