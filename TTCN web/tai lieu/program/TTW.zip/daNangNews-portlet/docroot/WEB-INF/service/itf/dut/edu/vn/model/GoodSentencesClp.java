/**
 * Copyright (c) 2000-2012 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package itf.dut.edu.vn.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.impl.BaseModelImpl;

import itf.dut.edu.vn.service.GoodSentencesLocalServiceUtil;

import java.io.Serializable;

import java.lang.reflect.Proxy;

/**
 * @author thanhlikes09
 */
public class GoodSentencesClp extends BaseModelImpl<GoodSentences>
	implements GoodSentences {
	public GoodSentencesClp() {
	}

	public Class<?> getModelClass() {
		return GoodSentences.class;
	}

	public String getModelClassName() {
		return GoodSentences.class.getName();
	}

	public int getPrimaryKey() {
		return _sentenceId;
	}

	public void setPrimaryKey(int primaryKey) {
		setSentenceId(primaryKey);
	}

	public Serializable getPrimaryKeyObj() {
		return new Integer(_sentenceId);
	}

	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Integer)primaryKeyObj).intValue());
	}

	public int getSentenceId() {
		return _sentenceId;
	}

	public void setSentenceId(int sentenceId) {
		_sentenceId = sentenceId;
	}

	public String getSentence() {
		return _sentence;
	}

	public void setSentence(String sentence) {
		_sentence = sentence;
	}

	public int getDay() {
		return _day;
	}

	public void setDay(int day) {
		_day = day;
	}

	public long getGroupId() {
		return _groupId;
	}

	public void setGroupId(long groupId) {
		_groupId = groupId;
	}

	public long getCompanyId() {
		return _companyId;
	}

	public void setCompanyId(long companyId) {
		_companyId = companyId;
	}

	public void persist() throws SystemException {
		if (this.isNew()) {
			GoodSentencesLocalServiceUtil.addGoodSentences(this);
		}
		else {
			GoodSentencesLocalServiceUtil.updateGoodSentences(this);
		}
	}

	@Override
	public GoodSentences toEscapedModel() {
		return (GoodSentences)Proxy.newProxyInstance(GoodSentences.class.getClassLoader(),
			new Class[] { GoodSentences.class }, new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		GoodSentencesClp clone = new GoodSentencesClp();

		clone.setSentenceId(getSentenceId());
		clone.setSentence(getSentence());
		clone.setDay(getDay());
		clone.setGroupId(getGroupId());
		clone.setCompanyId(getCompanyId());

		return clone;
	}

	public int compareTo(GoodSentences goodSentences) {
		int primaryKey = goodSentences.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		}

		GoodSentencesClp goodSentences = null;

		try {
			goodSentences = (GoodSentencesClp)obj;
		}
		catch (ClassCastException cce) {
			return false;
		}

		int primaryKey = goodSentences.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	@Override
	public int hashCode() {
		return getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(11);

		sb.append("{sentenceId=");
		sb.append(getSentenceId());
		sb.append(", sentence=");
		sb.append(getSentence());
		sb.append(", day=");
		sb.append(getDay());
		sb.append(", groupId=");
		sb.append(getGroupId());
		sb.append(", companyId=");
		sb.append(getCompanyId());
		sb.append("}");

		return sb.toString();
	}

	public String toXmlString() {
		StringBundler sb = new StringBundler(19);

		sb.append("<model><model-name>");
		sb.append("itf.dut.edu.vn.model.GoodSentences");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>sentenceId</column-name><column-value><![CDATA[");
		sb.append(getSentenceId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>sentence</column-name><column-value><![CDATA[");
		sb.append(getSentence());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>day</column-name><column-value><![CDATA[");
		sb.append(getDay());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>groupId</column-name><column-value><![CDATA[");
		sb.append(getGroupId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>companyId</column-name><column-value><![CDATA[");
		sb.append(getCompanyId());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private int _sentenceId;
	private String _sentence;
	private int _day;
	private long _groupId;
	private long _companyId;
}