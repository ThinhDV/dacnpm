/**
 * Copyright (c) 2000-2012 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package itf.dut.edu.vn.service;

import com.liferay.portal.service.ServiceWrapper;

/**
 * <p>
 * This class is a wrapper for {@link AdvertiseLocalService}.
 * </p>
 *
 * @author    thanhlikes09
 * @see       AdvertiseLocalService
 * @generated
 */
public class AdvertiseLocalServiceWrapper implements AdvertiseLocalService,
	ServiceWrapper<AdvertiseLocalService> {
	public AdvertiseLocalServiceWrapper(
		AdvertiseLocalService advertiseLocalService) {
		_advertiseLocalService = advertiseLocalService;
	}

	/**
	* Adds the advertise to the database. Also notifies the appropriate model listeners.
	*
	* @param advertise the advertise
	* @return the advertise that was added
	* @throws SystemException if a system exception occurred
	*/
	public itf.dut.edu.vn.model.Advertise addAdvertise(
		itf.dut.edu.vn.model.Advertise advertise)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _advertiseLocalService.addAdvertise(advertise);
	}

	/**
	* Creates a new advertise with the primary key. Does not add the advertise to the database.
	*
	* @param advertiseId the primary key for the new advertise
	* @return the new advertise
	*/
	public itf.dut.edu.vn.model.Advertise createAdvertise(long advertiseId) {
		return _advertiseLocalService.createAdvertise(advertiseId);
	}

	/**
	* Deletes the advertise with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param advertiseId the primary key of the advertise
	* @throws PortalException if a advertise with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public void deleteAdvertise(long advertiseId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		_advertiseLocalService.deleteAdvertise(advertiseId);
	}

	/**
	* Deletes the advertise from the database. Also notifies the appropriate model listeners.
	*
	* @param advertise the advertise
	* @throws SystemException if a system exception occurred
	*/
	public void deleteAdvertise(itf.dut.edu.vn.model.Advertise advertise)
		throws com.liferay.portal.kernel.exception.SystemException {
		_advertiseLocalService.deleteAdvertise(advertise);
	}

	/**
	* Performs a dynamic query on the database and returns the matching rows.
	*
	* @param dynamicQuery the dynamic query
	* @return the matching rows
	* @throws SystemException if a system exception occurred
	*/
	@SuppressWarnings("rawtypes")
	public java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _advertiseLocalService.dynamicQuery(dynamicQuery);
	}

	/**
	* Performs a dynamic query on the database and returns a range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @return the range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@SuppressWarnings("rawtypes")
	public java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) throws com.liferay.portal.kernel.exception.SystemException {
		return _advertiseLocalService.dynamicQuery(dynamicQuery, start, end);
	}

	/**
	* Performs a dynamic query on the database and returns an ordered range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@SuppressWarnings("rawtypes")
	public java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _advertiseLocalService.dynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _advertiseLocalService.dynamicQueryCount(dynamicQuery);
	}

	public itf.dut.edu.vn.model.Advertise fetchAdvertise(long advertiseId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _advertiseLocalService.fetchAdvertise(advertiseId);
	}

	/**
	* Returns the advertise with the primary key.
	*
	* @param advertiseId the primary key of the advertise
	* @return the advertise
	* @throws PortalException if a advertise with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public itf.dut.edu.vn.model.Advertise getAdvertise(long advertiseId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _advertiseLocalService.getAdvertise(advertiseId);
	}

	public com.liferay.portal.model.PersistedModel getPersistedModel(
		java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _advertiseLocalService.getPersistedModel(primaryKeyObj);
	}

	/**
	* Returns a range of all the advertises.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set.
	* </p>
	*
	* @param start the lower bound of the range of advertises
	* @param end the upper bound of the range of advertises (not inclusive)
	* @return the range of advertises
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<itf.dut.edu.vn.model.Advertise> getAdvertises(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _advertiseLocalService.getAdvertises(start, end);
	}

	/**
	* Returns the number of advertises.
	*
	* @return the number of advertises
	* @throws SystemException if a system exception occurred
	*/
	public int getAdvertisesCount()
		throws com.liferay.portal.kernel.exception.SystemException {
		return _advertiseLocalService.getAdvertisesCount();
	}

	/**
	* Updates the advertise in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	*
	* @param advertise the advertise
	* @return the advertise that was updated
	* @throws SystemException if a system exception occurred
	*/
	public itf.dut.edu.vn.model.Advertise updateAdvertise(
		itf.dut.edu.vn.model.Advertise advertise)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _advertiseLocalService.updateAdvertise(advertise);
	}

	/**
	* Updates the advertise in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	*
	* @param advertise the advertise
	* @param merge whether to merge the advertise with the current session. See {@link com.liferay.portal.service.persistence.BatchSession#update(com.liferay.portal.kernel.dao.orm.Session, com.liferay.portal.model.BaseModel, boolean)} for an explanation.
	* @return the advertise that was updated
	* @throws SystemException if a system exception occurred
	*/
	public itf.dut.edu.vn.model.Advertise updateAdvertise(
		itf.dut.edu.vn.model.Advertise advertise, boolean merge)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _advertiseLocalService.updateAdvertise(advertise, merge);
	}

	/**
	* Returns the Spring bean ID for this bean.
	*
	* @return the Spring bean ID for this bean
	*/
	public java.lang.String getBeanIdentifier() {
		return _advertiseLocalService.getBeanIdentifier();
	}

	/**
	* Sets the Spring bean ID for this bean.
	*
	* @param beanIdentifier the Spring bean ID for this bean
	*/
	public void setBeanIdentifier(java.lang.String beanIdentifier) {
		_advertiseLocalService.setBeanIdentifier(beanIdentifier);
	}

	/**
	 * @deprecated Renamed to {@link #getWrappedService}
	 */
	public AdvertiseLocalService getWrappedAdvertiseLocalService() {
		return _advertiseLocalService;
	}

	/**
	 * @deprecated Renamed to {@link #setWrappedService}
	 */
	public void setWrappedAdvertiseLocalService(
		AdvertiseLocalService advertiseLocalService) {
		_advertiseLocalService = advertiseLocalService;
	}

	public AdvertiseLocalService getWrappedService() {
		return _advertiseLocalService;
	}

	public void setWrappedService(AdvertiseLocalService advertiseLocalService) {
		_advertiseLocalService = advertiseLocalService;
	}

	private AdvertiseLocalService _advertiseLocalService;
}