/**
 * Copyright (c) 2000-2012 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package itf.dut.edu.vn.service;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.BaseModel;

import itf.dut.edu.vn.model.AdvertiseClp;
import itf.dut.edu.vn.model.CategoryClp;
import itf.dut.edu.vn.model.CommentClp;
import itf.dut.edu.vn.model.GoodSentencesClp;
import itf.dut.edu.vn.model.NewsClp;

import java.lang.reflect.Method;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author Brian Wing Shun Chan
 */
public class ClpSerializer {
	public static String getServletContextName() {
		if (Validator.isNotNull(_servletContextName)) {
			return _servletContextName;
		}

		synchronized (ClpSerializer.class) {
			if (Validator.isNotNull(_servletContextName)) {
				return _servletContextName;
			}

			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Class<?> portletPropsClass = classLoader.loadClass(
						"com.liferay.util.portlet.PortletProps");

				Method getMethod = portletPropsClass.getMethod("get",
						new Class<?>[] { String.class });

				String portletPropsServletContextName = (String)getMethod.invoke(null,
						"daNangNews-portlet-deployment-context");

				if (Validator.isNotNull(portletPropsServletContextName)) {
					_servletContextName = portletPropsServletContextName;
				}
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info(
						"Unable to locate deployment context from portlet properties");
				}
			}

			if (Validator.isNull(_servletContextName)) {
				try {
					String propsUtilServletContextName = PropsUtil.get(
							"daNangNews-portlet-deployment-context");

					if (Validator.isNotNull(propsUtilServletContextName)) {
						_servletContextName = propsUtilServletContextName;
					}
				}
				catch (Throwable t) {
					if (_log.isInfoEnabled()) {
						_log.info(
							"Unable to locate deployment context from portal properties");
					}
				}
			}

			if (Validator.isNull(_servletContextName)) {
				_servletContextName = "daNangNews-portlet";
			}

			return _servletContextName;
		}
	}

	public static void setClassLoader(ClassLoader classLoader) {
		_classLoader = classLoader;
	}

	public static Object translateInput(BaseModel<?> oldModel) {
		Class<?> oldModelClass = oldModel.getClass();

		String oldModelClassName = oldModelClass.getName();

		if (oldModelClassName.equals(AdvertiseClp.class.getName())) {
			return translateInputAdvertise(oldModel);
		}

		if (oldModelClassName.equals(CategoryClp.class.getName())) {
			return translateInputCategory(oldModel);
		}

		if (oldModelClassName.equals(CommentClp.class.getName())) {
			return translateInputComment(oldModel);
		}

		if (oldModelClassName.equals(GoodSentencesClp.class.getName())) {
			return translateInputGoodSentences(oldModel);
		}

		if (oldModelClassName.equals(NewsClp.class.getName())) {
			return translateInputNews(oldModel);
		}

		return oldModel;
	}

	public static Object translateInput(List<Object> oldList) {
		List<Object> newList = new ArrayList<Object>(oldList.size());

		for (int i = 0; i < oldList.size(); i++) {
			Object curObj = oldList.get(i);

			newList.add(translateInput(curObj));
		}

		return newList;
	}

	public static Object translateInputAdvertise(BaseModel<?> oldModel) {
		AdvertiseClp oldCplModel = (AdvertiseClp)oldModel;

		Thread currentThread = Thread.currentThread();

		ClassLoader contextClassLoader = currentThread.getContextClassLoader();

		try {
			currentThread.setContextClassLoader(_classLoader);

			try {
				Class<?> newModelClass = Class.forName("itf.dut.edu.vn.model.impl.AdvertiseImpl",
						true, _classLoader);

				Object newModel = newModelClass.newInstance();

				Method method0 = newModelClass.getMethod("setAdvertiseId",
						new Class[] { Long.TYPE });

				Long value0 = new Long(oldCplModel.getAdvertiseId());

				method0.invoke(newModel, value0);

				Method method1 = newModelClass.getMethod("setDescribe",
						new Class[] { String.class });

				String value1 = oldCplModel.getDescribe();

				method1.invoke(newModel, value1);

				Method method2 = newModelClass.getMethod("setUrl",
						new Class[] { String.class });

				String value2 = oldCplModel.getUrl();

				method2.invoke(newModel, value2);

				Method method3 = newModelClass.getMethod("setUrlImage",
						new Class[] { String.class });

				String value3 = oldCplModel.getUrlImage();

				method3.invoke(newModel, value3);

				Method method4 = newModelClass.getMethod("setCountClick",
						new Class[] { Long.TYPE });

				Long value4 = new Long(oldCplModel.getCountClick());

				method4.invoke(newModel, value4);

				Method method5 = newModelClass.getMethod("setHide",
						new Class[] { Boolean.TYPE });

				Boolean value5 = new Boolean(oldCplModel.getHide());

				method5.invoke(newModel, value5);

				Method method6 = newModelClass.getMethod("setGroupId",
						new Class[] { Long.TYPE });

				Long value6 = new Long(oldCplModel.getGroupId());

				method6.invoke(newModel, value6);

				Method method7 = newModelClass.getMethod("setCompanyId",
						new Class[] { Long.TYPE });

				Long value7 = new Long(oldCplModel.getCompanyId());

				method7.invoke(newModel, value7);

				return newModel;
			}
			catch (Exception e) {
				_log.error(e, e);
			}
		}
		finally {
			currentThread.setContextClassLoader(contextClassLoader);
		}

		return oldModel;
	}

	public static Object translateInputCategory(BaseModel<?> oldModel) {
		CategoryClp oldCplModel = (CategoryClp)oldModel;

		Thread currentThread = Thread.currentThread();

		ClassLoader contextClassLoader = currentThread.getContextClassLoader();

		try {
			currentThread.setContextClassLoader(_classLoader);

			try {
				Class<?> newModelClass = Class.forName("itf.dut.edu.vn.model.impl.CategoryImpl",
						true, _classLoader);

				Object newModel = newModelClass.newInstance();

				Method method0 = newModelClass.getMethod("setCategoryId",
						new Class[] { Long.TYPE });

				Long value0 = new Long(oldCplModel.getCategoryId());

				method0.invoke(newModel, value0);

				Method method1 = newModelClass.getMethod("setNameCategory",
						new Class[] { String.class });

				String value1 = oldCplModel.getNameCategory();

				method1.invoke(newModel, value1);

				Method method2 = newModelClass.getMethod("setGroupId",
						new Class[] { Long.TYPE });

				Long value2 = new Long(oldCplModel.getGroupId());

				method2.invoke(newModel, value2);

				Method method3 = newModelClass.getMethod("setCompanyId",
						new Class[] { Long.TYPE });

				Long value3 = new Long(oldCplModel.getCompanyId());

				method3.invoke(newModel, value3);

				return newModel;
			}
			catch (Exception e) {
				_log.error(e, e);
			}
		}
		finally {
			currentThread.setContextClassLoader(contextClassLoader);
		}

		return oldModel;
	}

	public static Object translateInputComment(BaseModel<?> oldModel) {
		CommentClp oldCplModel = (CommentClp)oldModel;

		Thread currentThread = Thread.currentThread();

		ClassLoader contextClassLoader = currentThread.getContextClassLoader();

		try {
			currentThread.setContextClassLoader(_classLoader);

			try {
				Class<?> newModelClass = Class.forName("itf.dut.edu.vn.model.impl.CommentImpl",
						true, _classLoader);

				Object newModel = newModelClass.newInstance();

				Method method0 = newModelClass.getMethod("setCommentId",
						new Class[] { Long.TYPE });

				Long value0 = new Long(oldCplModel.getCommentId());

				method0.invoke(newModel, value0);

				Method method1 = newModelClass.getMethod("setNewsId",
						new Class[] { Long.TYPE });

				Long value1 = new Long(oldCplModel.getNewsId());

				method1.invoke(newModel, value1);

				Method method2 = newModelClass.getMethod("setName",
						new Class[] { String.class });

				String value2 = oldCplModel.getName();

				method2.invoke(newModel, value2);

				Method method3 = newModelClass.getMethod("setEmail",
						new Class[] { String.class });

				String value3 = oldCplModel.getEmail();

				method3.invoke(newModel, value3);

				Method method4 = newModelClass.getMethod("setAddress",
						new Class[] { String.class });

				String value4 = oldCplModel.getAddress();

				method4.invoke(newModel, value4);

				Method method5 = newModelClass.getMethod("setTitle",
						new Class[] { String.class });

				String value5 = oldCplModel.getTitle();

				method5.invoke(newModel, value5);

				Method method6 = newModelClass.getMethod("setContentComment",
						new Class[] { String.class });

				String value6 = oldCplModel.getContentComment();

				method6.invoke(newModel, value6);

				Method method7 = newModelClass.getMethod("setCreateDate",
						new Class[] { Date.class });

				Date value7 = oldCplModel.getCreateDate();

				method7.invoke(newModel, value7);

				Method method8 = newModelClass.getMethod("setGroupId",
						new Class[] { Long.TYPE });

				Long value8 = new Long(oldCplModel.getGroupId());

				method8.invoke(newModel, value8);

				Method method9 = newModelClass.getMethod("setCompanyId",
						new Class[] { Long.TYPE });

				Long value9 = new Long(oldCplModel.getCompanyId());

				method9.invoke(newModel, value9);

				return newModel;
			}
			catch (Exception e) {
				_log.error(e, e);
			}
		}
		finally {
			currentThread.setContextClassLoader(contextClassLoader);
		}

		return oldModel;
	}

	public static Object translateInputGoodSentences(BaseModel<?> oldModel) {
		GoodSentencesClp oldCplModel = (GoodSentencesClp)oldModel;

		Thread currentThread = Thread.currentThread();

		ClassLoader contextClassLoader = currentThread.getContextClassLoader();

		try {
			currentThread.setContextClassLoader(_classLoader);

			try {
				Class<?> newModelClass = Class.forName("itf.dut.edu.vn.model.impl.GoodSentencesImpl",
						true, _classLoader);

				Object newModel = newModelClass.newInstance();

				Method method0 = newModelClass.getMethod("setSentenceId",
						new Class[] { Integer.TYPE });

				Integer value0 = new Integer(oldCplModel.getSentenceId());

				method0.invoke(newModel, value0);

				Method method1 = newModelClass.getMethod("setSentence",
						new Class[] { String.class });

				String value1 = oldCplModel.getSentence();

				method1.invoke(newModel, value1);

				Method method2 = newModelClass.getMethod("setDay",
						new Class[] { Integer.TYPE });

				Integer value2 = new Integer(oldCplModel.getDay());

				method2.invoke(newModel, value2);

				Method method3 = newModelClass.getMethod("setGroupId",
						new Class[] { Long.TYPE });

				Long value3 = new Long(oldCplModel.getGroupId());

				method3.invoke(newModel, value3);

				Method method4 = newModelClass.getMethod("setCompanyId",
						new Class[] { Long.TYPE });

				Long value4 = new Long(oldCplModel.getCompanyId());

				method4.invoke(newModel, value4);

				return newModel;
			}
			catch (Exception e) {
				_log.error(e, e);
			}
		}
		finally {
			currentThread.setContextClassLoader(contextClassLoader);
		}

		return oldModel;
	}

	public static Object translateInputNews(BaseModel<?> oldModel) {
		NewsClp oldCplModel = (NewsClp)oldModel;

		Thread currentThread = Thread.currentThread();

		ClassLoader contextClassLoader = currentThread.getContextClassLoader();

		try {
			currentThread.setContextClassLoader(_classLoader);

			try {
				Class<?> newModelClass = Class.forName("itf.dut.edu.vn.model.impl.NewsImpl",
						true, _classLoader);

				Object newModel = newModelClass.newInstance();

				Method method0 = newModelClass.getMethod("setNewsId",
						new Class[] { Long.TYPE });

				Long value0 = new Long(oldCplModel.getNewsId());

				method0.invoke(newModel, value0);

				Method method1 = newModelClass.getMethod("setTitle",
						new Class[] { String.class });

				String value1 = oldCplModel.getTitle();

				method1.invoke(newModel, value1);

				Method method2 = newModelClass.getMethod("setUrlImage",
						new Class[] { String.class });

				String value2 = oldCplModel.getUrlImage();

				method2.invoke(newModel, value2);

				Method method3 = newModelClass.getMethod("setSummarize",
						new Class[] { String.class });

				String value3 = oldCplModel.getSummarize();

				method3.invoke(newModel, value3);

				Method method4 = newModelClass.getMethod("setCreateDate",
						new Class[] { Date.class });

				Date value4 = oldCplModel.getCreateDate();

				method4.invoke(newModel, value4);

				Method method5 = newModelClass.getMethod("setModifiedDate",
						new Class[] { Date.class });

				Date value5 = oldCplModel.getModifiedDate();

				method5.invoke(newModel, value5);

				Method method6 = newModelClass.getMethod("setCategoryId",
						new Class[] { Long.TYPE });

				Long value6 = new Long(oldCplModel.getCategoryId());

				method6.invoke(newModel, value6);

				Method method7 = newModelClass.getMethod("setContentNews",
						new Class[] { String.class });

				String value7 = oldCplModel.getContentNews();

				method7.invoke(newModel, value7);

				Method method8 = newModelClass.getMethod("setCountView",
						new Class[] { Long.TYPE });

				Long value8 = new Long(oldCplModel.getCountView());

				method8.invoke(newModel, value8);

				Method method9 = newModelClass.getMethod("setGroupId",
						new Class[] { Long.TYPE });

				Long value9 = new Long(oldCplModel.getGroupId());

				method9.invoke(newModel, value9);

				Method method10 = newModelClass.getMethod("setCompanyId",
						new Class[] { Long.TYPE });

				Long value10 = new Long(oldCplModel.getCompanyId());

				method10.invoke(newModel, value10);

				Method method11 = newModelClass.getMethod("setMainNews",
						new Class[] { Boolean.TYPE });

				Boolean value11 = new Boolean(oldCplModel.getMainNews());

				method11.invoke(newModel, value11);

				Method method12 = newModelClass.getMethod("setWriter",
						new Class[] { String.class });

				String value12 = oldCplModel.getWriter();

				method12.invoke(newModel, value12);

				return newModel;
			}
			catch (Exception e) {
				_log.error(e, e);
			}
		}
		finally {
			currentThread.setContextClassLoader(contextClassLoader);
		}

		return oldModel;
	}

	public static Object translateInput(Object obj) {
		if (obj instanceof BaseModel<?>) {
			return translateInput((BaseModel<?>)obj);
		}
		else if (obj instanceof List<?>) {
			return translateInput((List<Object>)obj);
		}
		else {
			return obj;
		}
	}

	public static Object translateOutput(BaseModel<?> oldModel) {
		Class<?> oldModelClass = oldModel.getClass();

		String oldModelClassName = oldModelClass.getName();

		if (oldModelClassName.equals("itf.dut.edu.vn.model.impl.AdvertiseImpl")) {
			return translateOutputAdvertise(oldModel);
		}

		if (oldModelClassName.equals("itf.dut.edu.vn.model.impl.CategoryImpl")) {
			return translateOutputCategory(oldModel);
		}

		if (oldModelClassName.equals("itf.dut.edu.vn.model.impl.CommentImpl")) {
			return translateOutputComment(oldModel);
		}

		if (oldModelClassName.equals(
					"itf.dut.edu.vn.model.impl.GoodSentencesImpl")) {
			return translateOutputGoodSentences(oldModel);
		}

		if (oldModelClassName.equals("itf.dut.edu.vn.model.impl.NewsImpl")) {
			return translateOutputNews(oldModel);
		}

		return oldModel;
	}

	public static Object translateOutput(List<Object> oldList) {
		List<Object> newList = new ArrayList<Object>(oldList.size());

		for (int i = 0; i < oldList.size(); i++) {
			Object curObj = oldList.get(i);

			newList.add(translateOutput(curObj));
		}

		return newList;
	}

	public static Object translateOutput(Object obj) {
		if (obj instanceof BaseModel<?>) {
			return translateOutput((BaseModel<?>)obj);
		}
		else if (obj instanceof List<?>) {
			return translateOutput((List<Object>)obj);
		}
		else {
			return obj;
		}
	}

	public static Object translateOutputAdvertise(BaseModel<?> oldModel) {
		Thread currentThread = Thread.currentThread();

		ClassLoader contextClassLoader = currentThread.getContextClassLoader();

		try {
			currentThread.setContextClassLoader(_classLoader);

			try {
				AdvertiseClp newModel = new AdvertiseClp();

				Class<?> oldModelClass = oldModel.getClass();

				Method method0 = oldModelClass.getMethod("getAdvertiseId");

				Long value0 = (Long)method0.invoke(oldModel, (Object[])null);

				newModel.setAdvertiseId(value0);

				Method method1 = oldModelClass.getMethod("getDescribe");

				String value1 = (String)method1.invoke(oldModel, (Object[])null);

				newModel.setDescribe(value1);

				Method method2 = oldModelClass.getMethod("getUrl");

				String value2 = (String)method2.invoke(oldModel, (Object[])null);

				newModel.setUrl(value2);

				Method method3 = oldModelClass.getMethod("getUrlImage");

				String value3 = (String)method3.invoke(oldModel, (Object[])null);

				newModel.setUrlImage(value3);

				Method method4 = oldModelClass.getMethod("getCountClick");

				Long value4 = (Long)method4.invoke(oldModel, (Object[])null);

				newModel.setCountClick(value4);

				Method method5 = oldModelClass.getMethod("getHide");

				Boolean value5 = (Boolean)method5.invoke(oldModel,
						(Object[])null);

				newModel.setHide(value5);

				Method method6 = oldModelClass.getMethod("getGroupId");

				Long value6 = (Long)method6.invoke(oldModel, (Object[])null);

				newModel.setGroupId(value6);

				Method method7 = oldModelClass.getMethod("getCompanyId");

				Long value7 = (Long)method7.invoke(oldModel, (Object[])null);

				newModel.setCompanyId(value7);

				return newModel;
			}
			catch (Exception e) {
				_log.error(e, e);
			}
		}
		finally {
			currentThread.setContextClassLoader(contextClassLoader);
		}

		return oldModel;
	}

	public static Object translateOutputCategory(BaseModel<?> oldModel) {
		Thread currentThread = Thread.currentThread();

		ClassLoader contextClassLoader = currentThread.getContextClassLoader();

		try {
			currentThread.setContextClassLoader(_classLoader);

			try {
				CategoryClp newModel = new CategoryClp();

				Class<?> oldModelClass = oldModel.getClass();

				Method method0 = oldModelClass.getMethod("getCategoryId");

				Long value0 = (Long)method0.invoke(oldModel, (Object[])null);

				newModel.setCategoryId(value0);

				Method method1 = oldModelClass.getMethod("getNameCategory");

				String value1 = (String)method1.invoke(oldModel, (Object[])null);

				newModel.setNameCategory(value1);

				Method method2 = oldModelClass.getMethod("getGroupId");

				Long value2 = (Long)method2.invoke(oldModel, (Object[])null);

				newModel.setGroupId(value2);

				Method method3 = oldModelClass.getMethod("getCompanyId");

				Long value3 = (Long)method3.invoke(oldModel, (Object[])null);

				newModel.setCompanyId(value3);

				return newModel;
			}
			catch (Exception e) {
				_log.error(e, e);
			}
		}
		finally {
			currentThread.setContextClassLoader(contextClassLoader);
		}

		return oldModel;
	}

	public static Object translateOutputComment(BaseModel<?> oldModel) {
		Thread currentThread = Thread.currentThread();

		ClassLoader contextClassLoader = currentThread.getContextClassLoader();

		try {
			currentThread.setContextClassLoader(_classLoader);

			try {
				CommentClp newModel = new CommentClp();

				Class<?> oldModelClass = oldModel.getClass();

				Method method0 = oldModelClass.getMethod("getCommentId");

				Long value0 = (Long)method0.invoke(oldModel, (Object[])null);

				newModel.setCommentId(value0);

				Method method1 = oldModelClass.getMethod("getNewsId");

				Long value1 = (Long)method1.invoke(oldModel, (Object[])null);

				newModel.setNewsId(value1);

				Method method2 = oldModelClass.getMethod("getName");

				String value2 = (String)method2.invoke(oldModel, (Object[])null);

				newModel.setName(value2);

				Method method3 = oldModelClass.getMethod("getEmail");

				String value3 = (String)method3.invoke(oldModel, (Object[])null);

				newModel.setEmail(value3);

				Method method4 = oldModelClass.getMethod("getAddress");

				String value4 = (String)method4.invoke(oldModel, (Object[])null);

				newModel.setAddress(value4);

				Method method5 = oldModelClass.getMethod("getTitle");

				String value5 = (String)method5.invoke(oldModel, (Object[])null);

				newModel.setTitle(value5);

				Method method6 = oldModelClass.getMethod("getContentComment");

				String value6 = (String)method6.invoke(oldModel, (Object[])null);

				newModel.setContentComment(value6);

				Method method7 = oldModelClass.getMethod("getCreateDate");

				Date value7 = (Date)method7.invoke(oldModel, (Object[])null);

				newModel.setCreateDate(value7);

				Method method8 = oldModelClass.getMethod("getGroupId");

				Long value8 = (Long)method8.invoke(oldModel, (Object[])null);

				newModel.setGroupId(value8);

				Method method9 = oldModelClass.getMethod("getCompanyId");

				Long value9 = (Long)method9.invoke(oldModel, (Object[])null);

				newModel.setCompanyId(value9);

				return newModel;
			}
			catch (Exception e) {
				_log.error(e, e);
			}
		}
		finally {
			currentThread.setContextClassLoader(contextClassLoader);
		}

		return oldModel;
	}

	public static Object translateOutputGoodSentences(BaseModel<?> oldModel) {
		Thread currentThread = Thread.currentThread();

		ClassLoader contextClassLoader = currentThread.getContextClassLoader();

		try {
			currentThread.setContextClassLoader(_classLoader);

			try {
				GoodSentencesClp newModel = new GoodSentencesClp();

				Class<?> oldModelClass = oldModel.getClass();

				Method method0 = oldModelClass.getMethod("getSentenceId");

				Integer value0 = (Integer)method0.invoke(oldModel,
						(Object[])null);

				newModel.setSentenceId(value0);

				Method method1 = oldModelClass.getMethod("getSentence");

				String value1 = (String)method1.invoke(oldModel, (Object[])null);

				newModel.setSentence(value1);

				Method method2 = oldModelClass.getMethod("getDay");

				Integer value2 = (Integer)method2.invoke(oldModel,
						(Object[])null);

				newModel.setDay(value2);

				Method method3 = oldModelClass.getMethod("getGroupId");

				Long value3 = (Long)method3.invoke(oldModel, (Object[])null);

				newModel.setGroupId(value3);

				Method method4 = oldModelClass.getMethod("getCompanyId");

				Long value4 = (Long)method4.invoke(oldModel, (Object[])null);

				newModel.setCompanyId(value4);

				return newModel;
			}
			catch (Exception e) {
				_log.error(e, e);
			}
		}
		finally {
			currentThread.setContextClassLoader(contextClassLoader);
		}

		return oldModel;
	}

	public static Object translateOutputNews(BaseModel<?> oldModel) {
		Thread currentThread = Thread.currentThread();

		ClassLoader contextClassLoader = currentThread.getContextClassLoader();

		try {
			currentThread.setContextClassLoader(_classLoader);

			try {
				NewsClp newModel = new NewsClp();

				Class<?> oldModelClass = oldModel.getClass();

				Method method0 = oldModelClass.getMethod("getNewsId");

				Long value0 = (Long)method0.invoke(oldModel, (Object[])null);

				newModel.setNewsId(value0);

				Method method1 = oldModelClass.getMethod("getTitle");

				String value1 = (String)method1.invoke(oldModel, (Object[])null);

				newModel.setTitle(value1);

				Method method2 = oldModelClass.getMethod("getUrlImage");

				String value2 = (String)method2.invoke(oldModel, (Object[])null);

				newModel.setUrlImage(value2);

				Method method3 = oldModelClass.getMethod("getSummarize");

				String value3 = (String)method3.invoke(oldModel, (Object[])null);

				newModel.setSummarize(value3);

				Method method4 = oldModelClass.getMethod("getCreateDate");

				Date value4 = (Date)method4.invoke(oldModel, (Object[])null);

				newModel.setCreateDate(value4);

				Method method5 = oldModelClass.getMethod("getModifiedDate");

				Date value5 = (Date)method5.invoke(oldModel, (Object[])null);

				newModel.setModifiedDate(value5);

				Method method6 = oldModelClass.getMethod("getCategoryId");

				Long value6 = (Long)method6.invoke(oldModel, (Object[])null);

				newModel.setCategoryId(value6);

				Method method7 = oldModelClass.getMethod("getContentNews");

				String value7 = (String)method7.invoke(oldModel, (Object[])null);

				newModel.setContentNews(value7);

				Method method8 = oldModelClass.getMethod("getCountView");

				Long value8 = (Long)method8.invoke(oldModel, (Object[])null);

				newModel.setCountView(value8);

				Method method9 = oldModelClass.getMethod("getGroupId");

				Long value9 = (Long)method9.invoke(oldModel, (Object[])null);

				newModel.setGroupId(value9);

				Method method10 = oldModelClass.getMethod("getCompanyId");

				Long value10 = (Long)method10.invoke(oldModel, (Object[])null);

				newModel.setCompanyId(value10);

				Method method11 = oldModelClass.getMethod("getMainNews");

				Boolean value11 = (Boolean)method11.invoke(oldModel,
						(Object[])null);

				newModel.setMainNews(value11);

				Method method12 = oldModelClass.getMethod("getWriter");

				String value12 = (String)method12.invoke(oldModel,
						(Object[])null);

				newModel.setWriter(value12);

				return newModel;
			}
			catch (Exception e) {
				_log.error(e, e);
			}
		}
		finally {
			currentThread.setContextClassLoader(contextClassLoader);
		}

		return oldModel;
	}

	private static Log _log = LogFactoryUtil.getLog(ClpSerializer.class);
	private static ClassLoader _classLoader;
	private static String _servletContextName;
}