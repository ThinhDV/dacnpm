/**
 * Copyright (c) 2000-2012 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package itf.dut.edu.vn.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link itf.dut.edu.vn.service.http.GoodSentencesServiceSoap}.
 *
 * @author    thanhlikes09
 * @see       itf.dut.edu.vn.service.http.GoodSentencesServiceSoap
 * @generated
 */
public class GoodSentencesSoap implements Serializable {
	public static GoodSentencesSoap toSoapModel(GoodSentences model) {
		GoodSentencesSoap soapModel = new GoodSentencesSoap();

		soapModel.setSentenceId(model.getSentenceId());
		soapModel.setSentence(model.getSentence());
		soapModel.setDay(model.getDay());
		soapModel.setGroupId(model.getGroupId());
		soapModel.setCompanyId(model.getCompanyId());

		return soapModel;
	}

	public static GoodSentencesSoap[] toSoapModels(GoodSentences[] models) {
		GoodSentencesSoap[] soapModels = new GoodSentencesSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static GoodSentencesSoap[][] toSoapModels(GoodSentences[][] models) {
		GoodSentencesSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new GoodSentencesSoap[models.length][models[0].length];
		}
		else {
			soapModels = new GoodSentencesSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static GoodSentencesSoap[] toSoapModels(List<GoodSentences> models) {
		List<GoodSentencesSoap> soapModels = new ArrayList<GoodSentencesSoap>(models.size());

		for (GoodSentences model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new GoodSentencesSoap[soapModels.size()]);
	}

	public GoodSentencesSoap() {
	}

	public int getPrimaryKey() {
		return _sentenceId;
	}

	public void setPrimaryKey(int pk) {
		setSentenceId(pk);
	}

	public int getSentenceId() {
		return _sentenceId;
	}

	public void setSentenceId(int sentenceId) {
		_sentenceId = sentenceId;
	}

	public String getSentence() {
		return _sentence;
	}

	public void setSentence(String sentence) {
		_sentence = sentence;
	}

	public int getDay() {
		return _day;
	}

	public void setDay(int day) {
		_day = day;
	}

	public long getGroupId() {
		return _groupId;
	}

	public void setGroupId(long groupId) {
		_groupId = groupId;
	}

	public long getCompanyId() {
		return _companyId;
	}

	public void setCompanyId(long companyId) {
		_companyId = companyId;
	}

	private int _sentenceId;
	private String _sentence;
	private int _day;
	private long _groupId;
	private long _companyId;
}