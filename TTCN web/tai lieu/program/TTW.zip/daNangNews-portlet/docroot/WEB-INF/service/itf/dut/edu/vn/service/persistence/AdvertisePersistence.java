/**
 * Copyright (c) 2000-2012 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package itf.dut.edu.vn.service.persistence;

import com.liferay.portal.service.persistence.BasePersistence;

import itf.dut.edu.vn.model.Advertise;

/**
 * The persistence interface for the advertise service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author thanhlikes09
 * @see AdvertisePersistenceImpl
 * @see AdvertiseUtil
 * @generated
 */
public interface AdvertisePersistence extends BasePersistence<Advertise> {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link AdvertiseUtil} to access the advertise persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	* Caches the advertise in the entity cache if it is enabled.
	*
	* @param advertise the advertise
	*/
	public void cacheResult(itf.dut.edu.vn.model.Advertise advertise);

	/**
	* Caches the advertises in the entity cache if it is enabled.
	*
	* @param advertises the advertises
	*/
	public void cacheResult(
		java.util.List<itf.dut.edu.vn.model.Advertise> advertises);

	/**
	* Creates a new advertise with the primary key. Does not add the advertise to the database.
	*
	* @param advertiseId the primary key for the new advertise
	* @return the new advertise
	*/
	public itf.dut.edu.vn.model.Advertise create(long advertiseId);

	/**
	* Removes the advertise with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param advertiseId the primary key of the advertise
	* @return the advertise that was removed
	* @throws itf.dut.edu.vn.NoSuchAdvertiseException if a advertise with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public itf.dut.edu.vn.model.Advertise remove(long advertiseId)
		throws com.liferay.portal.kernel.exception.SystemException,
			itf.dut.edu.vn.NoSuchAdvertiseException;

	public itf.dut.edu.vn.model.Advertise updateImpl(
		itf.dut.edu.vn.model.Advertise advertise, boolean merge)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the advertise with the primary key or throws a {@link itf.dut.edu.vn.NoSuchAdvertiseException} if it could not be found.
	*
	* @param advertiseId the primary key of the advertise
	* @return the advertise
	* @throws itf.dut.edu.vn.NoSuchAdvertiseException if a advertise with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public itf.dut.edu.vn.model.Advertise findByPrimaryKey(long advertiseId)
		throws com.liferay.portal.kernel.exception.SystemException,
			itf.dut.edu.vn.NoSuchAdvertiseException;

	/**
	* Returns the advertise with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param advertiseId the primary key of the advertise
	* @return the advertise, or <code>null</code> if a advertise with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public itf.dut.edu.vn.model.Advertise fetchByPrimaryKey(long advertiseId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the advertises.
	*
	* @return the advertises
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<itf.dut.edu.vn.model.Advertise> findAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the advertises.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set.
	* </p>
	*
	* @param start the lower bound of the range of advertises
	* @param end the upper bound of the range of advertises (not inclusive)
	* @return the range of advertises
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<itf.dut.edu.vn.model.Advertise> findAll(int start,
		int end) throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the advertises.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set.
	* </p>
	*
	* @param start the lower bound of the range of advertises
	* @param end the upper bound of the range of advertises (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of advertises
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<itf.dut.edu.vn.model.Advertise> findAll(int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the advertises from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of advertises.
	*
	* @return the number of advertises
	* @throws SystemException if a system exception occurred
	*/
	public int countAll()
		throws com.liferay.portal.kernel.exception.SystemException;
}