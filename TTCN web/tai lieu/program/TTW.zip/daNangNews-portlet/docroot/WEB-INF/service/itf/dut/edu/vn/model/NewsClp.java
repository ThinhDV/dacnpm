/**
 * Copyright (c) 2000-2012 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package itf.dut.edu.vn.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.DateUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.impl.BaseModelImpl;

import itf.dut.edu.vn.service.NewsLocalServiceUtil;

import java.io.Serializable;

import java.lang.reflect.Proxy;

import java.util.Date;

/**
 * @author thanhlikes09
 */
public class NewsClp extends BaseModelImpl<News> implements News {
	public NewsClp() {
	}

	public Class<?> getModelClass() {
		return News.class;
	}

	public String getModelClassName() {
		return News.class.getName();
	}

	public long getPrimaryKey() {
		return _newsId;
	}

	public void setPrimaryKey(long primaryKey) {
		setNewsId(primaryKey);
	}

	public Serializable getPrimaryKeyObj() {
		return new Long(_newsId);
	}

	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	public long getNewsId() {
		return _newsId;
	}

	public void setNewsId(long newsId) {
		_newsId = newsId;
	}

	public String getTitle() {
		return _title;
	}

	public void setTitle(String title) {
		_title = title;
	}

	public String getUrlImage() {
		return _urlImage;
	}

	public void setUrlImage(String urlImage) {
		_urlImage = urlImage;
	}

	public String getSummarize() {
		return _summarize;
	}

	public void setSummarize(String summarize) {
		_summarize = summarize;
	}

	public Date getCreateDate() {
		return _createDate;
	}

	public void setCreateDate(Date createDate) {
		_createDate = createDate;
	}

	public Date getModifiedDate() {
		return _modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		_modifiedDate = modifiedDate;
	}

	public long getCategoryId() {
		return _categoryId;
	}

	public void setCategoryId(long categoryId) {
		_categoryId = categoryId;
	}

	public String getContentNews() {
		return _contentNews;
	}

	public void setContentNews(String contentNews) {
		_contentNews = contentNews;
	}

	public long getCountView() {
		return _countView;
	}

	public void setCountView(long countView) {
		_countView = countView;
	}

	public long getGroupId() {
		return _groupId;
	}

	public void setGroupId(long groupId) {
		_groupId = groupId;
	}

	public long getCompanyId() {
		return _companyId;
	}

	public void setCompanyId(long companyId) {
		_companyId = companyId;
	}

	public boolean getMainNews() {
		return _mainNews;
	}

	public boolean isMainNews() {
		return _mainNews;
	}

	public void setMainNews(boolean mainNews) {
		_mainNews = mainNews;
	}

	public String getWriter() {
		return _writer;
	}

	public void setWriter(String writer) {
		_writer = writer;
	}

	public void persist() throws SystemException {
		if (this.isNew()) {
			NewsLocalServiceUtil.addNews(this);
		}
		else {
			NewsLocalServiceUtil.updateNews(this);
		}
	}

	@Override
	public News toEscapedModel() {
		return (News)Proxy.newProxyInstance(News.class.getClassLoader(),
			new Class[] { News.class }, new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		NewsClp clone = new NewsClp();

		clone.setNewsId(getNewsId());
		clone.setTitle(getTitle());
		clone.setUrlImage(getUrlImage());
		clone.setSummarize(getSummarize());
		clone.setCreateDate(getCreateDate());
		clone.setModifiedDate(getModifiedDate());
		clone.setCategoryId(getCategoryId());
		clone.setContentNews(getContentNews());
		clone.setCountView(getCountView());
		clone.setGroupId(getGroupId());
		clone.setCompanyId(getCompanyId());
		clone.setMainNews(getMainNews());
		clone.setWriter(getWriter());

		return clone;
	}

	public int compareTo(News news) {
		int value = 0;

		value = DateUtil.compareTo(getCreateDate(), news.getCreateDate());

		value = value * -1;

		if (value != 0) {
			return value;
		}

		return 0;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		}

		NewsClp news = null;

		try {
			news = (NewsClp)obj;
		}
		catch (ClassCastException cce) {
			return false;
		}

		long primaryKey = news.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(27);

		sb.append("{newsId=");
		sb.append(getNewsId());
		sb.append(", title=");
		sb.append(getTitle());
		sb.append(", urlImage=");
		sb.append(getUrlImage());
		sb.append(", summarize=");
		sb.append(getSummarize());
		sb.append(", createDate=");
		sb.append(getCreateDate());
		sb.append(", modifiedDate=");
		sb.append(getModifiedDate());
		sb.append(", categoryId=");
		sb.append(getCategoryId());
		sb.append(", contentNews=");
		sb.append(getContentNews());
		sb.append(", countView=");
		sb.append(getCountView());
		sb.append(", groupId=");
		sb.append(getGroupId());
		sb.append(", companyId=");
		sb.append(getCompanyId());
		sb.append(", mainNews=");
		sb.append(getMainNews());
		sb.append(", writer=");
		sb.append(getWriter());
		sb.append("}");

		return sb.toString();
	}

	public String toXmlString() {
		StringBundler sb = new StringBundler(43);

		sb.append("<model><model-name>");
		sb.append("itf.dut.edu.vn.model.News");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>newsId</column-name><column-value><![CDATA[");
		sb.append(getNewsId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>title</column-name><column-value><![CDATA[");
		sb.append(getTitle());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>urlImage</column-name><column-value><![CDATA[");
		sb.append(getUrlImage());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>summarize</column-name><column-value><![CDATA[");
		sb.append(getSummarize());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>createDate</column-name><column-value><![CDATA[");
		sb.append(getCreateDate());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>modifiedDate</column-name><column-value><![CDATA[");
		sb.append(getModifiedDate());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>categoryId</column-name><column-value><![CDATA[");
		sb.append(getCategoryId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>contentNews</column-name><column-value><![CDATA[");
		sb.append(getContentNews());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>countView</column-name><column-value><![CDATA[");
		sb.append(getCountView());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>groupId</column-name><column-value><![CDATA[");
		sb.append(getGroupId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>companyId</column-name><column-value><![CDATA[");
		sb.append(getCompanyId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>mainNews</column-name><column-value><![CDATA[");
		sb.append(getMainNews());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>writer</column-name><column-value><![CDATA[");
		sb.append(getWriter());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _newsId;
	private String _title;
	private String _urlImage;
	private String _summarize;
	private Date _createDate;
	private Date _modifiedDate;
	private long _categoryId;
	private String _contentNews;
	private long _countView;
	private long _groupId;
	private long _companyId;
	private boolean _mainNews;
	private String _writer;
}