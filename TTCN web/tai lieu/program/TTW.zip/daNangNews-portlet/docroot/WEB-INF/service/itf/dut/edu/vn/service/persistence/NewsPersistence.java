/**
 * Copyright (c) 2000-2012 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package itf.dut.edu.vn.service.persistence;

import com.liferay.portal.service.persistence.BasePersistence;

import itf.dut.edu.vn.model.News;

/**
 * The persistence interface for the news service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author thanhlikes09
 * @see NewsPersistenceImpl
 * @see NewsUtil
 * @generated
 */
public interface NewsPersistence extends BasePersistence<News> {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link NewsUtil} to access the news persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	* Caches the news in the entity cache if it is enabled.
	*
	* @param news the news
	*/
	public void cacheResult(itf.dut.edu.vn.model.News news);

	/**
	* Caches the newses in the entity cache if it is enabled.
	*
	* @param newses the newses
	*/
	public void cacheResult(java.util.List<itf.dut.edu.vn.model.News> newses);

	/**
	* Creates a new news with the primary key. Does not add the news to the database.
	*
	* @param newsId the primary key for the new news
	* @return the new news
	*/
	public itf.dut.edu.vn.model.News create(long newsId);

	/**
	* Removes the news with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param newsId the primary key of the news
	* @return the news that was removed
	* @throws itf.dut.edu.vn.NoSuchNewsException if a news with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public itf.dut.edu.vn.model.News remove(long newsId)
		throws com.liferay.portal.kernel.exception.SystemException,
			itf.dut.edu.vn.NoSuchNewsException;

	public itf.dut.edu.vn.model.News updateImpl(
		itf.dut.edu.vn.model.News news, boolean merge)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the news with the primary key or throws a {@link itf.dut.edu.vn.NoSuchNewsException} if it could not be found.
	*
	* @param newsId the primary key of the news
	* @return the news
	* @throws itf.dut.edu.vn.NoSuchNewsException if a news with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public itf.dut.edu.vn.model.News findByPrimaryKey(long newsId)
		throws com.liferay.portal.kernel.exception.SystemException,
			itf.dut.edu.vn.NoSuchNewsException;

	/**
	* Returns the news with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param newsId the primary key of the news
	* @return the news, or <code>null</code> if a news with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public itf.dut.edu.vn.model.News fetchByPrimaryKey(long newsId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the news where title = &#63; or throws a {@link itf.dut.edu.vn.NoSuchNewsException} if it could not be found.
	*
	* @param title the title
	* @return the matching news
	* @throws itf.dut.edu.vn.NoSuchNewsException if a matching news could not be found
	* @throws SystemException if a system exception occurred
	*/
	public itf.dut.edu.vn.model.News findBytitle(java.lang.String title)
		throws com.liferay.portal.kernel.exception.SystemException,
			itf.dut.edu.vn.NoSuchNewsException;

	/**
	* Returns the news where title = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	*
	* @param title the title
	* @return the matching news, or <code>null</code> if a matching news could not be found
	* @throws SystemException if a system exception occurred
	*/
	public itf.dut.edu.vn.model.News fetchBytitle(java.lang.String title)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the news where title = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	*
	* @param title the title
	* @param retrieveFromCache whether to use the finder cache
	* @return the matching news, or <code>null</code> if a matching news could not be found
	* @throws SystemException if a system exception occurred
	*/
	public itf.dut.edu.vn.model.News fetchBytitle(java.lang.String title,
		boolean retrieveFromCache)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the news where contentNews = &#63; or throws a {@link itf.dut.edu.vn.NoSuchNewsException} if it could not be found.
	*
	* @param contentNews the content news
	* @return the matching news
	* @throws itf.dut.edu.vn.NoSuchNewsException if a matching news could not be found
	* @throws SystemException if a system exception occurred
	*/
	public itf.dut.edu.vn.model.News findBycontentNews(
		java.lang.String contentNews)
		throws com.liferay.portal.kernel.exception.SystemException,
			itf.dut.edu.vn.NoSuchNewsException;

	/**
	* Returns the news where contentNews = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	*
	* @param contentNews the content news
	* @return the matching news, or <code>null</code> if a matching news could not be found
	* @throws SystemException if a system exception occurred
	*/
	public itf.dut.edu.vn.model.News fetchBycontentNews(
		java.lang.String contentNews)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the news where contentNews = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	*
	* @param contentNews the content news
	* @param retrieveFromCache whether to use the finder cache
	* @return the matching news, or <code>null</code> if a matching news could not be found
	* @throws SystemException if a system exception occurred
	*/
	public itf.dut.edu.vn.model.News fetchBycontentNews(
		java.lang.String contentNews, boolean retrieveFromCache)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the news where categoryId = &#63; or throws a {@link itf.dut.edu.vn.NoSuchNewsException} if it could not be found.
	*
	* @param categoryId the category ID
	* @return the matching news
	* @throws itf.dut.edu.vn.NoSuchNewsException if a matching news could not be found
	* @throws SystemException if a system exception occurred
	*/
	public itf.dut.edu.vn.model.News findBycategoryId(long categoryId)
		throws com.liferay.portal.kernel.exception.SystemException,
			itf.dut.edu.vn.NoSuchNewsException;

	/**
	* Returns the news where categoryId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	*
	* @param categoryId the category ID
	* @return the matching news, or <code>null</code> if a matching news could not be found
	* @throws SystemException if a system exception occurred
	*/
	public itf.dut.edu.vn.model.News fetchBycategoryId(long categoryId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the news where categoryId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	*
	* @param categoryId the category ID
	* @param retrieveFromCache whether to use the finder cache
	* @return the matching news, or <code>null</code> if a matching news could not be found
	* @throws SystemException if a system exception occurred
	*/
	public itf.dut.edu.vn.model.News fetchBycategoryId(long categoryId,
		boolean retrieveFromCache)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the newses.
	*
	* @return the newses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<itf.dut.edu.vn.model.News> findAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the newses.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set.
	* </p>
	*
	* @param start the lower bound of the range of newses
	* @param end the upper bound of the range of newses (not inclusive)
	* @return the range of newses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<itf.dut.edu.vn.model.News> findAll(int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the newses.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set.
	* </p>
	*
	* @param start the lower bound of the range of newses
	* @param end the upper bound of the range of newses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of newses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<itf.dut.edu.vn.model.News> findAll(int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the news where title = &#63; from the database.
	*
	* @param title the title
	* @throws SystemException if a system exception occurred
	*/
	public void removeBytitle(java.lang.String title)
		throws com.liferay.portal.kernel.exception.SystemException,
			itf.dut.edu.vn.NoSuchNewsException;

	/**
	* Removes the news where contentNews = &#63; from the database.
	*
	* @param contentNews the content news
	* @throws SystemException if a system exception occurred
	*/
	public void removeBycontentNews(java.lang.String contentNews)
		throws com.liferay.portal.kernel.exception.SystemException,
			itf.dut.edu.vn.NoSuchNewsException;

	/**
	* Removes the news where categoryId = &#63; from the database.
	*
	* @param categoryId the category ID
	* @throws SystemException if a system exception occurred
	*/
	public void removeBycategoryId(long categoryId)
		throws com.liferay.portal.kernel.exception.SystemException,
			itf.dut.edu.vn.NoSuchNewsException;

	/**
	* Removes all the newses from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of newses where title = &#63;.
	*
	* @param title the title
	* @return the number of matching newses
	* @throws SystemException if a system exception occurred
	*/
	public int countBytitle(java.lang.String title)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of newses where contentNews = &#63;.
	*
	* @param contentNews the content news
	* @return the number of matching newses
	* @throws SystemException if a system exception occurred
	*/
	public int countBycontentNews(java.lang.String contentNews)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of newses where categoryId = &#63;.
	*
	* @param categoryId the category ID
	* @return the number of matching newses
	* @throws SystemException if a system exception occurred
	*/
	public int countBycategoryId(long categoryId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of newses.
	*
	* @return the number of newses
	* @throws SystemException if a system exception occurred
	*/
	public int countAll()
		throws com.liferay.portal.kernel.exception.SystemException;
}