/**
 * Copyright (c) 2000-2012 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package itf.dut.edu.vn.model;

import com.liferay.portal.model.ModelWrapper;

/**
 * <p>
 * This class is a wrapper for {@link News}.
 * </p>
 *
 * @author    thanhlikes09
 * @see       News
 * @generated
 */
public class NewsWrapper implements News, ModelWrapper<News> {
	public NewsWrapper(News news) {
		_news = news;
	}

	public Class<?> getModelClass() {
		return News.class;
	}

	public String getModelClassName() {
		return News.class.getName();
	}

	/**
	* Returns the primary key of this news.
	*
	* @return the primary key of this news
	*/
	public long getPrimaryKey() {
		return _news.getPrimaryKey();
	}

	/**
	* Sets the primary key of this news.
	*
	* @param primaryKey the primary key of this news
	*/
	public void setPrimaryKey(long primaryKey) {
		_news.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the news ID of this news.
	*
	* @return the news ID of this news
	*/
	public long getNewsId() {
		return _news.getNewsId();
	}

	/**
	* Sets the news ID of this news.
	*
	* @param newsId the news ID of this news
	*/
	public void setNewsId(long newsId) {
		_news.setNewsId(newsId);
	}

	/**
	* Returns the title of this news.
	*
	* @return the title of this news
	*/
	public java.lang.String getTitle() {
		return _news.getTitle();
	}

	/**
	* Sets the title of this news.
	*
	* @param title the title of this news
	*/
	public void setTitle(java.lang.String title) {
		_news.setTitle(title);
	}

	/**
	* Returns the url image of this news.
	*
	* @return the url image of this news
	*/
	public java.lang.String getUrlImage() {
		return _news.getUrlImage();
	}

	/**
	* Sets the url image of this news.
	*
	* @param urlImage the url image of this news
	*/
	public void setUrlImage(java.lang.String urlImage) {
		_news.setUrlImage(urlImage);
	}

	/**
	* Returns the summarize of this news.
	*
	* @return the summarize of this news
	*/
	public java.lang.String getSummarize() {
		return _news.getSummarize();
	}

	/**
	* Sets the summarize of this news.
	*
	* @param summarize the summarize of this news
	*/
	public void setSummarize(java.lang.String summarize) {
		_news.setSummarize(summarize);
	}

	/**
	* Returns the create date of this news.
	*
	* @return the create date of this news
	*/
	public java.util.Date getCreateDate() {
		return _news.getCreateDate();
	}

	/**
	* Sets the create date of this news.
	*
	* @param createDate the create date of this news
	*/
	public void setCreateDate(java.util.Date createDate) {
		_news.setCreateDate(createDate);
	}

	/**
	* Returns the modified date of this news.
	*
	* @return the modified date of this news
	*/
	public java.util.Date getModifiedDate() {
		return _news.getModifiedDate();
	}

	/**
	* Sets the modified date of this news.
	*
	* @param modifiedDate the modified date of this news
	*/
	public void setModifiedDate(java.util.Date modifiedDate) {
		_news.setModifiedDate(modifiedDate);
	}

	/**
	* Returns the category ID of this news.
	*
	* @return the category ID of this news
	*/
	public long getCategoryId() {
		return _news.getCategoryId();
	}

	/**
	* Sets the category ID of this news.
	*
	* @param categoryId the category ID of this news
	*/
	public void setCategoryId(long categoryId) {
		_news.setCategoryId(categoryId);
	}

	/**
	* Returns the content news of this news.
	*
	* @return the content news of this news
	*/
	public java.lang.String getContentNews() {
		return _news.getContentNews();
	}

	/**
	* Sets the content news of this news.
	*
	* @param contentNews the content news of this news
	*/
	public void setContentNews(java.lang.String contentNews) {
		_news.setContentNews(contentNews);
	}

	/**
	* Returns the count view of this news.
	*
	* @return the count view of this news
	*/
	public long getCountView() {
		return _news.getCountView();
	}

	/**
	* Sets the count view of this news.
	*
	* @param countView the count view of this news
	*/
	public void setCountView(long countView) {
		_news.setCountView(countView);
	}

	/**
	* Returns the group ID of this news.
	*
	* @return the group ID of this news
	*/
	public long getGroupId() {
		return _news.getGroupId();
	}

	/**
	* Sets the group ID of this news.
	*
	* @param groupId the group ID of this news
	*/
	public void setGroupId(long groupId) {
		_news.setGroupId(groupId);
	}

	/**
	* Returns the company ID of this news.
	*
	* @return the company ID of this news
	*/
	public long getCompanyId() {
		return _news.getCompanyId();
	}

	/**
	* Sets the company ID of this news.
	*
	* @param companyId the company ID of this news
	*/
	public void setCompanyId(long companyId) {
		_news.setCompanyId(companyId);
	}

	/**
	* Returns the main news of this news.
	*
	* @return the main news of this news
	*/
	public boolean getMainNews() {
		return _news.getMainNews();
	}

	/**
	* Returns <code>true</code> if this news is main news.
	*
	* @return <code>true</code> if this news is main news; <code>false</code> otherwise
	*/
	public boolean isMainNews() {
		return _news.isMainNews();
	}

	/**
	* Sets whether this news is main news.
	*
	* @param mainNews the main news of this news
	*/
	public void setMainNews(boolean mainNews) {
		_news.setMainNews(mainNews);
	}

	/**
	* Returns the writer of this news.
	*
	* @return the writer of this news
	*/
	public java.lang.String getWriter() {
		return _news.getWriter();
	}

	/**
	* Sets the writer of this news.
	*
	* @param writer the writer of this news
	*/
	public void setWriter(java.lang.String writer) {
		_news.setWriter(writer);
	}

	public boolean isNew() {
		return _news.isNew();
	}

	public void setNew(boolean n) {
		_news.setNew(n);
	}

	public boolean isCachedModel() {
		return _news.isCachedModel();
	}

	public void setCachedModel(boolean cachedModel) {
		_news.setCachedModel(cachedModel);
	}

	public boolean isEscapedModel() {
		return _news.isEscapedModel();
	}

	public java.io.Serializable getPrimaryKeyObj() {
		return _news.getPrimaryKeyObj();
	}

	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_news.setPrimaryKeyObj(primaryKeyObj);
	}

	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _news.getExpandoBridge();
	}

	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_news.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new NewsWrapper((News)_news.clone());
	}

	public int compareTo(itf.dut.edu.vn.model.News news) {
		return _news.compareTo(news);
	}

	@Override
	public int hashCode() {
		return _news.hashCode();
	}

	public com.liferay.portal.model.CacheModel<itf.dut.edu.vn.model.News> toCacheModel() {
		return _news.toCacheModel();
	}

	public itf.dut.edu.vn.model.News toEscapedModel() {
		return new NewsWrapper(_news.toEscapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _news.toString();
	}

	public java.lang.String toXmlString() {
		return _news.toXmlString();
	}

	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_news.persist();
	}

	/**
	 * @deprecated Renamed to {@link #getWrappedModel}
	 */
	public News getWrappedNews() {
		return _news;
	}

	public News getWrappedModel() {
		return _news;
	}

	public void resetOriginalValues() {
		_news.resetOriginalValues();
	}

	private News _news;
}