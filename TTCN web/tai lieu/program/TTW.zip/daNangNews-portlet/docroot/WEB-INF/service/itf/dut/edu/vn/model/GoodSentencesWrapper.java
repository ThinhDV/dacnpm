/**
 * Copyright (c) 2000-2012 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package itf.dut.edu.vn.model;

import com.liferay.portal.model.ModelWrapper;

/**
 * <p>
 * This class is a wrapper for {@link GoodSentences}.
 * </p>
 *
 * @author    thanhlikes09
 * @see       GoodSentences
 * @generated
 */
public class GoodSentencesWrapper implements GoodSentences,
	ModelWrapper<GoodSentences> {
	public GoodSentencesWrapper(GoodSentences goodSentences) {
		_goodSentences = goodSentences;
	}

	public Class<?> getModelClass() {
		return GoodSentences.class;
	}

	public String getModelClassName() {
		return GoodSentences.class.getName();
	}

	/**
	* Returns the primary key of this good sentences.
	*
	* @return the primary key of this good sentences
	*/
	public int getPrimaryKey() {
		return _goodSentences.getPrimaryKey();
	}

	/**
	* Sets the primary key of this good sentences.
	*
	* @param primaryKey the primary key of this good sentences
	*/
	public void setPrimaryKey(int primaryKey) {
		_goodSentences.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the sentence ID of this good sentences.
	*
	* @return the sentence ID of this good sentences
	*/
	public int getSentenceId() {
		return _goodSentences.getSentenceId();
	}

	/**
	* Sets the sentence ID of this good sentences.
	*
	* @param sentenceId the sentence ID of this good sentences
	*/
	public void setSentenceId(int sentenceId) {
		_goodSentences.setSentenceId(sentenceId);
	}

	/**
	* Returns the sentence of this good sentences.
	*
	* @return the sentence of this good sentences
	*/
	public java.lang.String getSentence() {
		return _goodSentences.getSentence();
	}

	/**
	* Sets the sentence of this good sentences.
	*
	* @param sentence the sentence of this good sentences
	*/
	public void setSentence(java.lang.String sentence) {
		_goodSentences.setSentence(sentence);
	}

	/**
	* Returns the day of this good sentences.
	*
	* @return the day of this good sentences
	*/
	public int getDay() {
		return _goodSentences.getDay();
	}

	/**
	* Sets the day of this good sentences.
	*
	* @param day the day of this good sentences
	*/
	public void setDay(int day) {
		_goodSentences.setDay(day);
	}

	/**
	* Returns the group ID of this good sentences.
	*
	* @return the group ID of this good sentences
	*/
	public long getGroupId() {
		return _goodSentences.getGroupId();
	}

	/**
	* Sets the group ID of this good sentences.
	*
	* @param groupId the group ID of this good sentences
	*/
	public void setGroupId(long groupId) {
		_goodSentences.setGroupId(groupId);
	}

	/**
	* Returns the company ID of this good sentences.
	*
	* @return the company ID of this good sentences
	*/
	public long getCompanyId() {
		return _goodSentences.getCompanyId();
	}

	/**
	* Sets the company ID of this good sentences.
	*
	* @param companyId the company ID of this good sentences
	*/
	public void setCompanyId(long companyId) {
		_goodSentences.setCompanyId(companyId);
	}

	public boolean isNew() {
		return _goodSentences.isNew();
	}

	public void setNew(boolean n) {
		_goodSentences.setNew(n);
	}

	public boolean isCachedModel() {
		return _goodSentences.isCachedModel();
	}

	public void setCachedModel(boolean cachedModel) {
		_goodSentences.setCachedModel(cachedModel);
	}

	public boolean isEscapedModel() {
		return _goodSentences.isEscapedModel();
	}

	public java.io.Serializable getPrimaryKeyObj() {
		return _goodSentences.getPrimaryKeyObj();
	}

	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_goodSentences.setPrimaryKeyObj(primaryKeyObj);
	}

	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _goodSentences.getExpandoBridge();
	}

	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_goodSentences.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new GoodSentencesWrapper((GoodSentences)_goodSentences.clone());
	}

	public int compareTo(itf.dut.edu.vn.model.GoodSentences goodSentences) {
		return _goodSentences.compareTo(goodSentences);
	}

	@Override
	public int hashCode() {
		return _goodSentences.hashCode();
	}

	public com.liferay.portal.model.CacheModel<itf.dut.edu.vn.model.GoodSentences> toCacheModel() {
		return _goodSentences.toCacheModel();
	}

	public itf.dut.edu.vn.model.GoodSentences toEscapedModel() {
		return new GoodSentencesWrapper(_goodSentences.toEscapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _goodSentences.toString();
	}

	public java.lang.String toXmlString() {
		return _goodSentences.toXmlString();
	}

	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_goodSentences.persist();
	}

	/**
	 * @deprecated Renamed to {@link #getWrappedModel}
	 */
	public GoodSentences getWrappedGoodSentences() {
		return _goodSentences;
	}

	public GoodSentences getWrappedModel() {
		return _goodSentences;
	}

	public void resetOriginalValues() {
		_goodSentences.resetOriginalValues();
	}

	private GoodSentences _goodSentences;
}