/**
 * Copyright (c) 2000-2012 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package itf.dut.edu.vn.model;

import com.liferay.portal.model.ModelWrapper;

/**
 * <p>
 * This class is a wrapper for {@link Advertise}.
 * </p>
 *
 * @author    thanhlikes09
 * @see       Advertise
 * @generated
 */
public class AdvertiseWrapper implements Advertise, ModelWrapper<Advertise> {
	public AdvertiseWrapper(Advertise advertise) {
		_advertise = advertise;
	}

	public Class<?> getModelClass() {
		return Advertise.class;
	}

	public String getModelClassName() {
		return Advertise.class.getName();
	}

	/**
	* Returns the primary key of this advertise.
	*
	* @return the primary key of this advertise
	*/
	public long getPrimaryKey() {
		return _advertise.getPrimaryKey();
	}

	/**
	* Sets the primary key of this advertise.
	*
	* @param primaryKey the primary key of this advertise
	*/
	public void setPrimaryKey(long primaryKey) {
		_advertise.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the advertise ID of this advertise.
	*
	* @return the advertise ID of this advertise
	*/
	public long getAdvertiseId() {
		return _advertise.getAdvertiseId();
	}

	/**
	* Sets the advertise ID of this advertise.
	*
	* @param advertiseId the advertise ID of this advertise
	*/
	public void setAdvertiseId(long advertiseId) {
		_advertise.setAdvertiseId(advertiseId);
	}

	/**
	* Returns the describe of this advertise.
	*
	* @return the describe of this advertise
	*/
	public java.lang.String getDescribe() {
		return _advertise.getDescribe();
	}

	/**
	* Sets the describe of this advertise.
	*
	* @param describe the describe of this advertise
	*/
	public void setDescribe(java.lang.String describe) {
		_advertise.setDescribe(describe);
	}

	/**
	* Returns the url of this advertise.
	*
	* @return the url of this advertise
	*/
	public java.lang.String getUrl() {
		return _advertise.getUrl();
	}

	/**
	* Sets the url of this advertise.
	*
	* @param url the url of this advertise
	*/
	public void setUrl(java.lang.String url) {
		_advertise.setUrl(url);
	}

	/**
	* Returns the url image of this advertise.
	*
	* @return the url image of this advertise
	*/
	public java.lang.String getUrlImage() {
		return _advertise.getUrlImage();
	}

	/**
	* Sets the url image of this advertise.
	*
	* @param urlImage the url image of this advertise
	*/
	public void setUrlImage(java.lang.String urlImage) {
		_advertise.setUrlImage(urlImage);
	}

	/**
	* Returns the count click of this advertise.
	*
	* @return the count click of this advertise
	*/
	public long getCountClick() {
		return _advertise.getCountClick();
	}

	/**
	* Sets the count click of this advertise.
	*
	* @param countClick the count click of this advertise
	*/
	public void setCountClick(long countClick) {
		_advertise.setCountClick(countClick);
	}

	/**
	* Returns the hide of this advertise.
	*
	* @return the hide of this advertise
	*/
	public boolean getHide() {
		return _advertise.getHide();
	}

	/**
	* Returns <code>true</code> if this advertise is hide.
	*
	* @return <code>true</code> if this advertise is hide; <code>false</code> otherwise
	*/
	public boolean isHide() {
		return _advertise.isHide();
	}

	/**
	* Sets whether this advertise is hide.
	*
	* @param hide the hide of this advertise
	*/
	public void setHide(boolean hide) {
		_advertise.setHide(hide);
	}

	/**
	* Returns the group ID of this advertise.
	*
	* @return the group ID of this advertise
	*/
	public long getGroupId() {
		return _advertise.getGroupId();
	}

	/**
	* Sets the group ID of this advertise.
	*
	* @param groupId the group ID of this advertise
	*/
	public void setGroupId(long groupId) {
		_advertise.setGroupId(groupId);
	}

	/**
	* Returns the company ID of this advertise.
	*
	* @return the company ID of this advertise
	*/
	public long getCompanyId() {
		return _advertise.getCompanyId();
	}

	/**
	* Sets the company ID of this advertise.
	*
	* @param companyId the company ID of this advertise
	*/
	public void setCompanyId(long companyId) {
		_advertise.setCompanyId(companyId);
	}

	public boolean isNew() {
		return _advertise.isNew();
	}

	public void setNew(boolean n) {
		_advertise.setNew(n);
	}

	public boolean isCachedModel() {
		return _advertise.isCachedModel();
	}

	public void setCachedModel(boolean cachedModel) {
		_advertise.setCachedModel(cachedModel);
	}

	public boolean isEscapedModel() {
		return _advertise.isEscapedModel();
	}

	public java.io.Serializable getPrimaryKeyObj() {
		return _advertise.getPrimaryKeyObj();
	}

	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_advertise.setPrimaryKeyObj(primaryKeyObj);
	}

	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _advertise.getExpandoBridge();
	}

	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_advertise.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new AdvertiseWrapper((Advertise)_advertise.clone());
	}

	public int compareTo(itf.dut.edu.vn.model.Advertise advertise) {
		return _advertise.compareTo(advertise);
	}

	@Override
	public int hashCode() {
		return _advertise.hashCode();
	}

	public com.liferay.portal.model.CacheModel<itf.dut.edu.vn.model.Advertise> toCacheModel() {
		return _advertise.toCacheModel();
	}

	public itf.dut.edu.vn.model.Advertise toEscapedModel() {
		return new AdvertiseWrapper(_advertise.toEscapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _advertise.toString();
	}

	public java.lang.String toXmlString() {
		return _advertise.toXmlString();
	}

	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_advertise.persist();
	}

	/**
	 * @deprecated Renamed to {@link #getWrappedModel}
	 */
	public Advertise getWrappedAdvertise() {
		return _advertise;
	}

	public Advertise getWrappedModel() {
		return _advertise;
	}

	public void resetOriginalValues() {
		_advertise.resetOriginalValues();
	}

	private Advertise _advertise;
}