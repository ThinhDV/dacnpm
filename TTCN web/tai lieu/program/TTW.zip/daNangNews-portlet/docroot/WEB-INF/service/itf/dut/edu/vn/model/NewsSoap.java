/**
 * Copyright (c) 2000-2012 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package itf.dut.edu.vn.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link itf.dut.edu.vn.service.http.NewsServiceSoap}.
 *
 * @author    thanhlikes09
 * @see       itf.dut.edu.vn.service.http.NewsServiceSoap
 * @generated
 */
public class NewsSoap implements Serializable {
	public static NewsSoap toSoapModel(News model) {
		NewsSoap soapModel = new NewsSoap();

		soapModel.setNewsId(model.getNewsId());
		soapModel.setTitle(model.getTitle());
		soapModel.setUrlImage(model.getUrlImage());
		soapModel.setSummarize(model.getSummarize());
		soapModel.setCreateDate(model.getCreateDate());
		soapModel.setModifiedDate(model.getModifiedDate());
		soapModel.setCategoryId(model.getCategoryId());
		soapModel.setContentNews(model.getContentNews());
		soapModel.setCountView(model.getCountView());
		soapModel.setGroupId(model.getGroupId());
		soapModel.setCompanyId(model.getCompanyId());
		soapModel.setMainNews(model.getMainNews());
		soapModel.setWriter(model.getWriter());

		return soapModel;
	}

	public static NewsSoap[] toSoapModels(News[] models) {
		NewsSoap[] soapModels = new NewsSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static NewsSoap[][] toSoapModels(News[][] models) {
		NewsSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new NewsSoap[models.length][models[0].length];
		}
		else {
			soapModels = new NewsSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static NewsSoap[] toSoapModels(List<News> models) {
		List<NewsSoap> soapModels = new ArrayList<NewsSoap>(models.size());

		for (News model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new NewsSoap[soapModels.size()]);
	}

	public NewsSoap() {
	}

	public long getPrimaryKey() {
		return _newsId;
	}

	public void setPrimaryKey(long pk) {
		setNewsId(pk);
	}

	public long getNewsId() {
		return _newsId;
	}

	public void setNewsId(long newsId) {
		_newsId = newsId;
	}

	public String getTitle() {
		return _title;
	}

	public void setTitle(String title) {
		_title = title;
	}

	public String getUrlImage() {
		return _urlImage;
	}

	public void setUrlImage(String urlImage) {
		_urlImage = urlImage;
	}

	public String getSummarize() {
		return _summarize;
	}

	public void setSummarize(String summarize) {
		_summarize = summarize;
	}

	public Date getCreateDate() {
		return _createDate;
	}

	public void setCreateDate(Date createDate) {
		_createDate = createDate;
	}

	public Date getModifiedDate() {
		return _modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		_modifiedDate = modifiedDate;
	}

	public long getCategoryId() {
		return _categoryId;
	}

	public void setCategoryId(long categoryId) {
		_categoryId = categoryId;
	}

	public String getContentNews() {
		return _contentNews;
	}

	public void setContentNews(String contentNews) {
		_contentNews = contentNews;
	}

	public long getCountView() {
		return _countView;
	}

	public void setCountView(long countView) {
		_countView = countView;
	}

	public long getGroupId() {
		return _groupId;
	}

	public void setGroupId(long groupId) {
		_groupId = groupId;
	}

	public long getCompanyId() {
		return _companyId;
	}

	public void setCompanyId(long companyId) {
		_companyId = companyId;
	}

	public boolean getMainNews() {
		return _mainNews;
	}

	public boolean isMainNews() {
		return _mainNews;
	}

	public void setMainNews(boolean mainNews) {
		_mainNews = mainNews;
	}

	public String getWriter() {
		return _writer;
	}

	public void setWriter(String writer) {
		_writer = writer;
	}

	private long _newsId;
	private String _title;
	private String _urlImage;
	private String _summarize;
	private Date _createDate;
	private Date _modifiedDate;
	private long _categoryId;
	private String _contentNews;
	private long _countView;
	private long _groupId;
	private long _companyId;
	private boolean _mainNews;
	private String _writer;
}