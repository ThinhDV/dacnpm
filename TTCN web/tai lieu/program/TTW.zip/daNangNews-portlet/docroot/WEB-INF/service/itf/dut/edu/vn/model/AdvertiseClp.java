/**
 * Copyright (c) 2000-2012 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package itf.dut.edu.vn.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.impl.BaseModelImpl;

import itf.dut.edu.vn.service.AdvertiseLocalServiceUtil;

import java.io.Serializable;

import java.lang.reflect.Proxy;

/**
 * @author thanhlikes09
 */
public class AdvertiseClp extends BaseModelImpl<Advertise> implements Advertise {
	public AdvertiseClp() {
	}

	public Class<?> getModelClass() {
		return Advertise.class;
	}

	public String getModelClassName() {
		return Advertise.class.getName();
	}

	public long getPrimaryKey() {
		return _advertiseId;
	}

	public void setPrimaryKey(long primaryKey) {
		setAdvertiseId(primaryKey);
	}

	public Serializable getPrimaryKeyObj() {
		return new Long(_advertiseId);
	}

	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	public long getAdvertiseId() {
		return _advertiseId;
	}

	public void setAdvertiseId(long advertiseId) {
		_advertiseId = advertiseId;
	}

	public String getDescribe() {
		return _describe;
	}

	public void setDescribe(String describe) {
		_describe = describe;
	}

	public String getUrl() {
		return _url;
	}

	public void setUrl(String url) {
		_url = url;
	}

	public String getUrlImage() {
		return _urlImage;
	}

	public void setUrlImage(String urlImage) {
		_urlImage = urlImage;
	}

	public long getCountClick() {
		return _countClick;
	}

	public void setCountClick(long countClick) {
		_countClick = countClick;
	}

	public boolean getHide() {
		return _hide;
	}

	public boolean isHide() {
		return _hide;
	}

	public void setHide(boolean hide) {
		_hide = hide;
	}

	public long getGroupId() {
		return _groupId;
	}

	public void setGroupId(long groupId) {
		_groupId = groupId;
	}

	public long getCompanyId() {
		return _companyId;
	}

	public void setCompanyId(long companyId) {
		_companyId = companyId;
	}

	public void persist() throws SystemException {
		if (this.isNew()) {
			AdvertiseLocalServiceUtil.addAdvertise(this);
		}
		else {
			AdvertiseLocalServiceUtil.updateAdvertise(this);
		}
	}

	@Override
	public Advertise toEscapedModel() {
		return (Advertise)Proxy.newProxyInstance(Advertise.class.getClassLoader(),
			new Class[] { Advertise.class }, new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		AdvertiseClp clone = new AdvertiseClp();

		clone.setAdvertiseId(getAdvertiseId());
		clone.setDescribe(getDescribe());
		clone.setUrl(getUrl());
		clone.setUrlImage(getUrlImage());
		clone.setCountClick(getCountClick());
		clone.setHide(getHide());
		clone.setGroupId(getGroupId());
		clone.setCompanyId(getCompanyId());

		return clone;
	}

	public int compareTo(Advertise advertise) {
		int value = 0;

		if (getGroupId() < advertise.getGroupId()) {
			value = -1;
		}
		else if (getGroupId() > advertise.getGroupId()) {
			value = 1;
		}
		else {
			value = 0;
		}

		if (value != 0) {
			return value;
		}

		return 0;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		}

		AdvertiseClp advertise = null;

		try {
			advertise = (AdvertiseClp)obj;
		}
		catch (ClassCastException cce) {
			return false;
		}

		long primaryKey = advertise.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(17);

		sb.append("{advertiseId=");
		sb.append(getAdvertiseId());
		sb.append(", describe=");
		sb.append(getDescribe());
		sb.append(", url=");
		sb.append(getUrl());
		sb.append(", urlImage=");
		sb.append(getUrlImage());
		sb.append(", countClick=");
		sb.append(getCountClick());
		sb.append(", hide=");
		sb.append(getHide());
		sb.append(", groupId=");
		sb.append(getGroupId());
		sb.append(", companyId=");
		sb.append(getCompanyId());
		sb.append("}");

		return sb.toString();
	}

	public String toXmlString() {
		StringBundler sb = new StringBundler(28);

		sb.append("<model><model-name>");
		sb.append("itf.dut.edu.vn.model.Advertise");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>advertiseId</column-name><column-value><![CDATA[");
		sb.append(getAdvertiseId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>describe</column-name><column-value><![CDATA[");
		sb.append(getDescribe());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>url</column-name><column-value><![CDATA[");
		sb.append(getUrl());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>urlImage</column-name><column-value><![CDATA[");
		sb.append(getUrlImage());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>countClick</column-name><column-value><![CDATA[");
		sb.append(getCountClick());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>hide</column-name><column-value><![CDATA[");
		sb.append(getHide());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>groupId</column-name><column-value><![CDATA[");
		sb.append(getGroupId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>companyId</column-name><column-value><![CDATA[");
		sb.append(getCompanyId());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _advertiseId;
	private String _describe;
	private String _url;
	private String _urlImage;
	private long _countClick;
	private boolean _hide;
	private long _groupId;
	private long _companyId;
}