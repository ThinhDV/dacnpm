/**
 * Copyright (c) 2000-2012 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package itf.dut.edu.vn.service.messaging;

import com.liferay.portal.kernel.messaging.BaseMessageListener;
import com.liferay.portal.kernel.messaging.Message;

import itf.dut.edu.vn.service.AdvertiseLocalServiceUtil;
import itf.dut.edu.vn.service.AdvertiseServiceUtil;
import itf.dut.edu.vn.service.CategoryLocalServiceUtil;
import itf.dut.edu.vn.service.CategoryServiceUtil;
import itf.dut.edu.vn.service.ClpSerializer;
import itf.dut.edu.vn.service.CommentLocalServiceUtil;
import itf.dut.edu.vn.service.CommentServiceUtil;
import itf.dut.edu.vn.service.GoodSentencesLocalServiceUtil;
import itf.dut.edu.vn.service.GoodSentencesServiceUtil;
import itf.dut.edu.vn.service.NewsLocalServiceUtil;
import itf.dut.edu.vn.service.NewsServiceUtil;

/**
 * @author Brian Wing Shun Chan
 */
public class ClpMessageListener extends BaseMessageListener {
	public static String getServletContextName() {
		return ClpSerializer.getServletContextName();
	}

	@Override
	protected void doReceive(Message message) throws Exception {
		String command = message.getString("command");
		String servletContextName = message.getString("servletContextName");

		if (command.equals("undeploy") &&
				servletContextName.equals(getServletContextName())) {
			AdvertiseLocalServiceUtil.clearService();

			AdvertiseServiceUtil.clearService();
			CategoryLocalServiceUtil.clearService();

			CategoryServiceUtil.clearService();
			CommentLocalServiceUtil.clearService();

			CommentServiceUtil.clearService();
			GoodSentencesLocalServiceUtil.clearService();

			GoodSentencesServiceUtil.clearService();
			NewsLocalServiceUtil.clearService();

			NewsServiceUtil.clearService();
		}
	}
}