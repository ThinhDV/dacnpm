/**
 * Copyright (c) 2000-2012 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.test.model.model;

import com.liferay.portal.model.ModelWrapper;

/**
 * <p>
 * This class is a wrapper for {@link News}.
 * </p>
 *
 * @author    thanhlikes09
 * @see       News
 * @generated
 */
public class NewsWrapper implements News, ModelWrapper<News> {
	public NewsWrapper(News news) {
		_news = news;
	}

	public Class<?> getModelClass() {
		return News.class;
	}

	public String getModelClassName() {
		return News.class.getName();
	}

	/**
	* Returns the primary key of this news.
	*
	* @return the primary key of this news
	*/
	public long getPrimaryKey() {
		return _news.getPrimaryKey();
	}

	/**
	* Sets the primary key of this news.
	*
	* @param primaryKey the primary key of this news
	*/
	public void setPrimaryKey(long primaryKey) {
		_news.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the ID of this news.
	*
	* @return the ID of this news
	*/
	public long getId() {
		return _news.getId();
	}

	/**
	* Sets the ID of this news.
	*
	* @param Id the ID of this news
	*/
	public void setId(long Id) {
		_news.setId(Id);
	}

	/**
	* Returns the title of this news.
	*
	* @return the title of this news
	*/
	public java.lang.String getTitle() {
		return _news.getTitle();
	}

	/**
	* Sets the title of this news.
	*
	* @param title the title of this news
	*/
	public void setTitle(java.lang.String title) {
		_news.setTitle(title);
	}

	/**
	* Returns the content of this news.
	*
	* @return the content of this news
	*/
	public java.lang.String getContent() {
		return _news.getContent();
	}

	/**
	* Sets the content of this news.
	*
	* @param content the content of this news
	*/
	public void setContent(java.lang.String content) {
		_news.setContent(content);
	}

	public boolean isNew() {
		return _news.isNew();
	}

	public void setNew(boolean n) {
		_news.setNew(n);
	}

	public boolean isCachedModel() {
		return _news.isCachedModel();
	}

	public void setCachedModel(boolean cachedModel) {
		_news.setCachedModel(cachedModel);
	}

	public boolean isEscapedModel() {
		return _news.isEscapedModel();
	}

	public java.io.Serializable getPrimaryKeyObj() {
		return _news.getPrimaryKeyObj();
	}

	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_news.setPrimaryKeyObj(primaryKeyObj);
	}

	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _news.getExpandoBridge();
	}

	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_news.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new NewsWrapper((News)_news.clone());
	}

	public int compareTo(com.test.model.model.News news) {
		return _news.compareTo(news);
	}

	@Override
	public int hashCode() {
		return _news.hashCode();
	}

	public com.liferay.portal.model.CacheModel<com.test.model.model.News> toCacheModel() {
		return _news.toCacheModel();
	}

	public com.test.model.model.News toEscapedModel() {
		return new NewsWrapper(_news.toEscapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _news.toString();
	}

	public java.lang.String toXmlString() {
		return _news.toXmlString();
	}

	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_news.persist();
	}

	/**
	 * @deprecated Renamed to {@link #getWrappedModel}
	 */
	public News getWrappedNews() {
		return _news;
	}

	public News getWrappedModel() {
		return _news;
	}

	public void resetOriginalValues() {
		_news.resetOriginalValues();
	}

	private News _news;
}