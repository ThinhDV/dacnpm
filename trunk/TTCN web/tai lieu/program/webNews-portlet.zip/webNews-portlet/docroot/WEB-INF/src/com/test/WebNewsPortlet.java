package com.test;

import java.io.IOException;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;

import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;
import com.test.model.model.News;
import com.test.model.model.impl.NewsImpl;
import com.test.model.service.NewsLocalServiceUtil;

/**
 * Portlet implementation class WebNewsPortlet
 */
public class WebNewsPortlet extends MVCPortlet {

	public void updateNews(ActionRequest actionRequest,
			ActionResponse actionResponse) throws IOException, PortletException {
		String NewsTitle = ParamUtil.getString(actionRequest, "NewsTitle");
		String NewsContent = ParamUtil.getString(actionRequest, "NewsContent");
		System.out.println(NewsContent + " " + NewsTitle);
		News news = new NewsImpl();
		long Id = 0l;
		try {
			Id = CounterLocalServiceUtil.increment(this.getClass().getName());
			
		} catch (SystemException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		news.setId(Id);
		news.setTitle(NewsTitle);
		news.setContent(NewsContent);
		try {
			NewsLocalServiceUtil.addNews(news);
		} catch (SystemException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
