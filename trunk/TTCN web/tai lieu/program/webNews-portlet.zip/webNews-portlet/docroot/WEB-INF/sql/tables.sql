create table NEWS_News (
	Id LONG not null primary key,
	title VARCHAR(75) null,
	content VARCHAR(75) null
);